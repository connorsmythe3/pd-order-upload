# Verification and rollout notes

Build: 0.1.5, 5 October 2026. Status: ready for staging installation; production site compatibility has not been certified.

## Checks performed

- 139 passing PHP assertions/syntax checks using WordPress Playground PHP 8.3 with actual ZIP and XMLReader extensions.
- CSV/XLSX fixtures: long SKUs, leading zeros, scientific notation, duplicate rows, invalid quantities/headers, file/row/cell limits, malformed archives, formulas, external worksheet references, XML external entities, macros and oversized expanded components.
- Account/request protection: guests, retail roles, nonce failures, wrong origin/method, cross-user/session tokens, expiry and missing cart dependencies.
- Stock and cart checks: held stock, existing quantities, unmanaged status, sold-individually, restricted products, changed stock, unaccepted reductions, native validation-hook rejection and partial failures.
- Durable review/locking regression checks: storage failures block confirmation and rate-limited parsing; atomic unique insert; duplicate insert rejected; previous lock owner cannot delete a replacement; expired locks recover on access; replay returns recorded result.
- Reports retain unresolved/excluded rows after adding valid items, preserve combined original quantities, and neutralise spreadsheet formula-like text.
- DOM flow checks for explicit stock acceptance, server revalidation, dirty quantities blocking confirmation, duplicate clicks, inert markup and final discount display.
- Chromium desktop/mobile rendering inspected. A mobile clipping regression was reproduced and fixed; the table fits the mobile panel without horizontal clipping. The Excel template's text format was inspected and a zero-prefixed SKU round-tripped through its exported XLSX structure.
- Real WordPress integration: WordPress 7.1.2, WooCommerce 11.1.2, Wholesale Prices free component 2.3.0, PHP 8.3.33 with SQLite in WordPress Playground. The shortcode loaded, the real wholesale role was recognised, 7 existing units limited a 30-stock item to 23 additional units, permissive product backorder settings were overridden for the upload, 23 accepted units were added at 4.68 ex tax, replay did not add again, and a custom add-to-cart validation hook was honoured.

- Real browser/AJAX workflow on that WordPress stack: uploaded a CSV requesting 40 units with 30 available plus an unknown SKU, explicitly accepted 30, confirmed without a page reload, displayed the actual 4.68 ex-tax unit price and retained the unknown row in the report. Guest AJAX access was denied. The test exited successfully. Currency rendering follows the site currency (the local fixture used USD).

## Popup update (0.1.1)

The same shortcode now renders a compact red button and a native modal dialog. Account bootstrap waits until opening. The dialog is moved outside Elementor containers, uses the browser top layer, and retains the existing upload/review/results DOM when closed. No cart/parser/access/pricing logic changed.

Test-first checks reproduced the missing button/modal behaviour. Chromium tests cover initially hidden panel, lazy bootstrap, native modal isolation, Escape/close/backdrop, restored focus, preserved reviews/results, continued ordering, one cart confirmation across reopening, and desktop/mobile layout. The actual WordPress AJAX upload-to-cart test also passed with the new launcher, including closing/reopening the final report and guest access denial. The existing inline-flow DOM test is retained as a regression check of the underlying ordering UI. Full automated checks pass for this build.

## Template and hover update (0.1.2)

Copied all 645 supplied SKU/title pairs into Products, with exact comparison against the uploaded sheet. Stored every reference SKU as an Excel text cell with Text formatting. Order remains the first worksheet, its 500 blank entry rows and quantity validation remain intact, and the updated template passes the real PHP XLSX parser round-trip check. Added the user's exact SKU instruction to Instructions and the popup's upload guidance. The product list is a static reference snapshot; live eligibility/stock still come from WooCommerce.

Instructions and Products were rendered and inspected. The rendering library displays some numeric-looking text in scientific notation in its preview; saved XLSX cells were separately verified as full literal text with @ formatting, which Excel displays as text. No SKU digits were guessed or altered.

Reproduced a theme hover rule changing radius, padding and scale. A scoped upload-button rule preserves all three and adds only a hover shadow. Chromium checks pass against the conflicting theme rule. Full PHP/DOM/modal/template regression checks pass. Cache versions and the template download URL were bumped. Backend ordering/security logic is unchanged.

## Review clarity and button update (0.1.3)

Removed the price column from the review; final actual ex-GST prices and discount badges are retained. Authorised review responses now include the exact product's current cart quantity, summing separate cart lines. The UI shows this count and states that adding the item increases the existing quantity. Restricted/unknown products expose no cart count. The warning is refreshed on upload/revision, not a reservation or a continuously updated cart snapshot.

Removed white/text action variants and applied #A30404 with white text throughout. Launcher/close retain their own shapes; row controls retain compact sizing. Only a shadow changes on hover. Disabled controls stay visibly disabled. The browser test simulates a conflicting theme, checks every available action in review/results and the launcher/close, verifies no placeholder column, and confirms the existing-cart warning. Native file selector is styled to match. Desktop/mobile review layouts were inspected. The real WordPress AJAX test with 7 units already in the cart showed the warning and allowed 23 additional units against stock of 30; accepted confirmation added 23 at 4.68 ex tax and retained the unknown SKU result. Guest access remained denied.

## Independent code review

A separate reviewer inspected the original 0.1.0 plugin and test code; its security fixes carry forward unchanged. The later UI/template updates received implementer review and browser regression testing. No Critical finding was reported. Two Important findings identified WordPress's non-atomic add_option upsert and unchecked confirmation-state persistence. Both were fixed with a unique database insert, owner-conditional release and durable compare-and-update review transitions.

Three initially Minor findings were also treated as Important for this customer workflow: interrupted locks must recover, merged source quantities must remain accurate, and unresolved rows must remain in the final report. Each was reproduced in a regression test and fixed. The implementer additionally reproduced/fixed mobile clipping, unexpected plugin exception messages exposing internals, and rate-limit storage failure. The complete suite passed after the fix pass. No review findings were deferred.

This was a code review and targeted automated testing, not an external penetration test or a guarantee against every future vulnerability.

## Decisions and practical limits

- A separate project/plugin isolates the existing snippets. Bootstrap/controller registration was delivered together. Cost if this packaging choice is wrong: placement/activation changes, not modifications to existing plugin files.
- Tests use PHP WASM because a native PHP CLI was unavailable. Real WordPress core/plugin execution was also tested, but hosting-specific behaviour remains a staging responsibility.
- Locks expire after five minutes and recover with compare-and-delete. A terminated request can cause a short retry delay; an uncertain confirmation instructs the customer to check their cart.
- No verified Premium quantity-preview API/source was supplied. The review price column is omitted; actual prices show after confirmation. Product-level tier badges are verified against real cart prices. Category/global/custom discounts can change prices without this badge. Cost: exact prices are not previewed before confirmation.
- SKU matching is exact, including case; mismatches are flagged rather than guessed. The template uses a verified Excel Text format. Customers must preserve Text formatting when pasting; previously damaged SKUs cannot be restored.
- The site-specific Premium, Elementor, Order Form 3.1.2, Tall Emu and existing snippets are outside the verified integration stack. They must pass the included staging checklist before production use.
- Checkout-only minimum/order rules still run at checkout. Upload confirmation honours add-to-cart validation hooks, but cannot certify rules that a plugin only implements elsewhere without that plugin/version and staging evidence.
- Upload review is not a stock reservation. Locks serialise upload requests; unrelated cart endpoints use WooCommerce's normal session/stock behaviour. Existing checkout stock validation remains authoritative.
- Simple products and whole-unit quantities are supported. Backorders and variations outside this upload are not modified.
- Harmless executable-looking text remains inert data. Uploaded files are temporary, never executed or published; server/hosting hardening and routine WordPress maintenance remain external responsibilities.

## Staging checklist

Follow readme.txt. Test the complete portal, both add-to-cart paths, stock warnings, minimum/carton rules, tier discounts and tax, mini-cart count, checkout, existing toasts, Tall Emu export and plugin deactivation. Record your installed versions. Only install on the live portal after these checks pass.

## Launcher icon (0.1.4)

Added a small white upload arrow/tray SVG before Upload Order, matching the supplied reference. The decorative symbol is hidden from assistive technologies; the button keeps its text label, existing click handler and shadow-only hover. No remote icon library or asset dependency. PHP syntax/shortcode checks and a rendered launcher inspection passed; the preceding full UI/security checks remain unchanged for this presentation-only edit.

## Hover shadow (0.1.5)

All button hover shadows use centred black: 0 0 10px rgb(0 0 0 / 30%). Non-hover shadows are suppressed even under theme overrides. Button colour and geometry stay unchanged. CSS-only presentation update; rendered/computed browser inspection and PHP syntax/shortcode checks passed.


## Security hardening (0.1.6, 6 October 2026)

CSV and XLSX retained. Added account request throttling, bounded streamed ZIP reads with actual size/CRC checks, structural content-type checks, active/embedded/archive-path restrictions, XML node/depth limits, complete workbook traversal, and cleanup cursor batches. Final verification: 170 PHP checks each on PHP 8.1 and 8.3, Excel reference/round-trip, DOM and Chromium modal checks, and 18 real WordPress/WooCommerce HTTP security checks passed. Independent AI source review found no remaining blockers. See the separate security report and test bundle for scope and limitations; this is not a formal penetration test or production-stack approval.


## Upload limits (0.1.7, 8 October 2026)

Maximum actual file size is 250 KB (256,000 bytes), enforced in both the browser and server parser. CSV and XLSX remain supported. One server-side upload attempt per account every 120 seconds, including rejected attempts; different login sessions share the budget. Rejected requests do not extend the cooldown. Review editing, reports and confirmation keep the existing separate 30-request/minute budget.

New regression checks were observed failing before the implementation, then passing: exact size accepted, one byte over rejected, client oversize rejection without sending a file, separate-account budgets, cross-login enforcement and expiry/new-window behaviour. The bundled Excel template is 24,462 bytes and fits the limit. Full verification passed: 179 PHP checks each on PHP 8.1 and 8.3; Excel XML/reference/round-trip, browser DOM and Chromium desktop/mobile modal checks. The real WordPress/WooCommerce HTTP integration suite was adjusted to use separate accounts for file cases under the stricter cooldown, but was not rerun for this revision. Production-site plugin compatibility remains subject to the staging checklist.

This release does not add an audit log or retain original uploaded files; originals remain temporary. An admin-only upload log and private evidence retention are separate proposed additions.


## Private upload log and email alerts (0.1.8, 9 October 2026)

Added a dedicated WordPress table, admin-only WooCommerce log with pagination/filtering/row detail and related-event links, optional configured-recipient plain-text security emails, rolling failure thresholds, bounded duplicate cooldown records and 7–365-day retention (default 90). Emails are initially off. No original upload retention, email attachments, passwords or session tokens. Logs begin after installation and are not tamper-proof evidence. Authentication/nonce failures and account-lock contention are outside this application log.

Counter and mail reservation writes run while the existing account lock is held. Three server rejection/throttle failures in a rolling ten-minute window alert; suspicious parser-tagged failures alert immediately, with at most one mail/account/ten minutes. Known stock/SKU review issues do not alert. Customer ordering continues if audit/email infrastructure fails. Confirmation snapshots include observed additions before totals/session persistence errors or later-row lookup failures; an unverifiable resulting quantity is explicitly uncertain.

Verification: 229 PHP checks passed each on PHP 8.1 and 8.3, plus template/reference/round-trip, DOM and Chromium modal checks. Seven additional real WordPress 7.1.3 database/admin/mail-handoff checks passed using Playground's SQLite database integration: idempotent dbDelta installation, real stored account/rows, intercepted wp_mail and grouping, subscriber access denial, escaped admin detail, listing/nonce forms and retention deletion. Mail was intercepted in tests; no email was sent externally. Actual SMTP inbox delivery must be checked on the target site. Independent source review found no remaining material blockers after fixes. The full WooCommerce multipart HTTP suite and target site's complete plugin stack were not rerun for this revision; follow staging acceptance checks.

Also restored the documented 20 MB aggregate expanded-XLSX budget: version 0.1.7 accidentally reduced it to 2,560,000 bytes during an upload-size substring edit. Regression tests now cover a bounded 16 MB archive and rejection over 20 MB. The 250 KB actual upload, 5 MB component, XML node/depth and other restrictions remain enforced.


## reCAPTCHA and rolling upload budgets (0.1.9, 9 October 2026)

Added classic v2 checkbox configuration under WooCommerce > Order Upload Log. Administrator/POST/nonce-protected saving; blank secret retains its stored value, explicit deletion clears it, and no saved secret is rendered or returned publicly. Default is disabled pending configuration. Enabled but incomplete configuration fails closed. Upload allowance is consumed before verification and parsing. Five attempts per rolling 60 seconds and twenty per rolling 86,400 seconds, per account across sessions, with account locking and fail-closed persistence. Already-throttled requests do not consume additional slots. 250 KB and other parser bounds are unchanged. Proactive file/row/frequency-limit notices are removed from the upload panel; blocked actions still show useful errors.

The server uses WordPress HTTP POST to a fixed HTTPS Google siteverify endpoint, with bounded timeout/response size, strict success and portal hostname checks. Missing/expired/duplicate/invalid tokens, network errors, malformed responses and wrong hosts block uploads. Secret/token contents do not enter the audit log. Review/confirm/report remain independent of a fresh CAPTCHA.

Google API is loaded only when enabled and the wholesale popup is opened. Widget resets per submission and popup close; upload is unavailable until solved. A matching widget-instance anchor/challenge iframe pair is moved into a modal descendant/popover host so the native modal does not make the image challenge inert. Exact host/path/site-key checks and instance isolation preserve unrelated widgets even using the same key. This relies on Google's widget DOM and needs staging verification with real image challenges after service updates.

Verification: 273 PHP checks each passed on PHP 8.1 and 8.3, template/reference/round-trip, existing DOM/modal checks, CAPTCHA expiry/reset/submission checks and Chromium mobile popup/challenge/other-widget isolation checks. A native-close-event timing race in the browser test was corrected by waiting for observable popover closure/reset. Missing/invalid enabled CAPTCHA dispatcher tests prove rejection before parsing and consumed allowance. Admin tests cover unauthorized/GET/invalid-nonce changes and secret nondisclosure. Independent review found no remaining material blockers. Google HTTP/client responses were controlled fixtures; no customer keys were available, and real Google challenge/token verification, target-site SMTP and the site's full plugin stack remain staging checks. The full WooCommerce HTTP integration suite was updated for the new budgets but not rerun for this revision.


## Supplied Excel template (0.1.10, 9 October 2026)

Replaced assets/order-template.xlsx byte-for-byte with the attached PD-order-template.xlsx (41,599 bytes). Preserved its Order, Instructions and Products sheets, Excel Text SKU formatting and item-name lookup formulas. Updated the product-reference fixture to match this supplied revision. Bumped plugin and asset/download cache versions.

The supplied lookup formulas made previously unused rows appear as missing-SKU errors. A failing parser regression reproduced this before adding a skip for rows with empty plain SKU and Quantity fields. Other columns remain reference-only; input formulas still produce errors, and existing file/XML/row bounds remain enforced. PHP 8.3 full regression suite, template checks, CAPTCHA UI and Chromium modal checks passed. PHP 8.1 template/parser security checks also passed. Live target-site validation remains a staging check.


## Audit remediation candidate 0.2.0 — 9 October 2026

The following is new verification; earlier sections describe earlier builds. Reproducible tests and native measurements are provided separately in the remediation evidence bundle. This candidate remains a staging build.

- Parser regression: 34 audit cases pass on native PHP 8.3.6/libxml 2.9.14 and PHP-WASM 8.1, including dense CSV, 100,000 XML attributes, alternate-encoding DTD, formula dependents, coordinates and inert reference formulas. Supplied workbook unchanged (SHA-256 a11aae10006d9bcb7f929d7bd6d1f327e59e60b5a1215ae61ee20381531a2f85). Three-process standalone measurements: dense CSV PHP peak falls from57,387,792 to1,596,200 bytes; XML attribute stress falls from13,238ms accepted to3.68ms rejected.
- Native HTTP: actual WordPress7.1.3, WooCommerce11.2.0, Wholesale Prices free2.3.0 and MariaDB10.11.14. Real multipart uploads, saved database carts and7.50 wholesale pricing verified for20/100/500-row orders;500-row uploads also checked against500 preexisting cart lines. Competing normal cart writers, misleading other-account token headers and cookie-free Store API cart tokens receive409 before stale session loading, then retry without overwriting quantities.
- Native load:500 rows into empty cart14.3s total; into500-line cart27.3s total in bounded requests. Largest serial batch3.02s. Eight accounts simultaneously uploaded/confirmed500 rows each in25.3s wall time; largest batch3.41s. These synthetic local measurements are not target-host capacity guarantees. Wholesale Prices itself calculates totals per addition; its hooks remain active.
- Recovery: durable intent written before mutation; SQL cart persistence checked before progress; SIGKILL/fatal timeout require cart check and never replay uncertain work. Expired processing is retained in one account pending record and can be recovered from another login; completed/unconfirmed records still expire. Original session reviews are retired before mutation/finalisation to prevent resurrection.
- Audit/edit/background tests: serialized review caps, substantive edit/hourly row-work caps,64KiB event/2MiB account-day detail budgets and truthful truncation, revision deltas, metadata-only admin listings, asynchronous bounded alerts, cache refresh after SMTP, cleanup cursors/catch-up/backoff and opt-in uninstall deletion. Red buttons/hover-only black shadows and16px mobile inputs remain.
- Fresh independent whole-branch review found audit gating, queue cache and Store API identity issues; fixes and regression tests were applied. Expiration/new-login recovery was then independently reviewed and corrected.

Release limits: the exact licensed Premium/Elementor/Order Form stack, real Google tokens, SMTP delivery, persistent object-cache deployment, proxy/host timeout and physical iPhone Safari have not been verified here. Premium minimum/step preview is intentionally not inferred from carton attributes or guessed metadata; native final ordering validation stays active. Native PHP8.1 was unavailable (8.1 tests use WASM). Native MySQL/MariaDB GET_LOCK and stable database connections are required; unsupported session/token handlers fail closed. Finish/check any interrupted older-version upload before upgrade; older session-bound tokens cannot be mapped automatically to new logins.

Final verification on packaged source: both full portable suites exit0, each with456 named PHP checks plus five browser/UI suites. Fresh native recovery evidence source hashes match every PHP include. SQL-expired account pending survives bootstrap/advance; a new login acknowledges20 uncertain rows; original-login replay performs zero additions/totals and leaves the cart unchanged. Fresh500-row upload against500-line existing cart completes in10 batches,29.61s total, longest request3.23s. Peak full HTTP PHP allocation107MiB, Linux worker lifetime RSS high-water114.89MiB; configured test memory512MiB/execution90s. This measures whole WordPress/WooCommerce requests, not just parser heap, but remains specific to this isolated environment.


## Template refresh and version 1.0.0 — 9 October 2026

The Products reference now contains the612 entries from product-export-2026-10-09-12-38-51.csv. There are no blank or duplicate SKU keys. The existing Order lookup formulas now refer to Products rows2–613, with all500 order rows preserved. All612 SKU/name lookups calculate correctly in the authoring engine and after reopening the exported workbook. Missing/blank SKU behaviour and leading-zero alphanumeric keys were checked.

Product and order SKU cells retain Excel Text formatting, and product values are stored as strings. Order/Instructions cell values and styles are preserved apart from the requested lookup range changes; panes, column widths and quantity validation are retained. Targeted PHP8.3 parser/template, WordPress registration and syntax checks pass; PHP8.1 template/registration/syntax checks pass. Security/cart PHP includes are byte-identical to0.2.0; version/cache/template URL tags are1.0.0. Prior0.2.0 native audit evidence remains historical evidence for those unchanged modules.

Updated template SHA-256: 0cbaa536858b3199e532768370e89880087976a664ba607862077f0e29723e56. Excel desktop has not been executed here; verification covers the exported formulas, calculation/reopen and upload parser.
