<?php
/**
 * Plugin Name: Pure Distilling Order Upload
 * Description: Reviewed CSV/Excel ordering for logged-in wholesale customers. No backorders through uploads. Staging build.
 * Version: 1.0.0
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce,woocommerce-wholesale-prices
 * Author: Pure Distilling
 * License: GPL-2.0-or-later
 * Text Domain: pd-order-upload
 */
namespace PureDistilling\OrderUpload;
if (!defined('ABSPATH')) { exit; }

add_action('plugins_loaded', static function() {
    if (PHP_VERSION_ID < 80100) { return; }
    foreach (['upload-exception', 'parser', 'access', 'review-store', 'cart-guard', 'validator', 'pricing', 'controller', 'audit-log', 'audit-admin', 'captcha'] as $file) {
        require_once __DIR__ . '/includes/class-' . $file . '.php';
    }
    Controller::register();
    CartGuard::register();
    AuditLog::register();
    AuditAdmin::register();
    add_action('pdou_cleanup', [ReviewStore::class, 'cleanup']);
    add_action('pdou_cleanup_catchup', [ReviewStore::class, 'cleanup']);
    add_action('admin_init', static function() { if (!wp_next_scheduled('pdou_cleanup')) { wp_schedule_event(time()+300,'hourly','pdou_cleanup'); } });
});
add_action('before_woocommerce_init', static function() {
    if (class_exists('Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});
register_activation_hook(__FILE__, static function() {
    require_once __DIR__.'/includes/class-audit-log.php'; AuditLog::maybe_install();
    if (!wp_next_scheduled('pdou_cleanup')) { wp_schedule_event(time() + 300, 'hourly', 'pdou_cleanup'); }
});
register_deactivation_hook(__FILE__, static function() { foreach(['pdou_cleanup','pdou_cleanup_catchup','pdou_log_cleanup_catchup','pdou_alert_queue'] as $hook) { wp_clear_scheduled_hook($hook); } });

add_shortcode('pd_order_upload', static function(): string {
    if (PHP_VERSION_ID < 80100 || !class_exists('ZipArchive') || !class_exists('XMLReader')) {
        return '<p>Order upload is unavailable. Please use the order form below.</p>';
    }
    $url = plugin_dir_url(__FILE__);
    wp_enqueue_style('pd-order-upload', $url . 'assets/upload.css', [], '1.0.0');
    wp_enqueue_script('pd-order-upload', $url . 'assets/upload.js', [], '1.0.0', true);
    // Generic markup is safe to cache: no account/product data or security tokens.
    return '<div class="pdou-widget"><button type="button" class="pdou-launch" aria-haspopup="dialog"><svg class="pdou-launch-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 16V4m-4 4 4-4 4 4M5 15v5h14v-5"/></svg><span>Upload Order</span></button><dialog class="pdou-dialog" aria-label="Upload your order"><div class="pdou-modal-toolbar"><button type="button" class="pdou-close" aria-label="Close order upload">&times;</button></div><section class="pd-order-upload" aria-label="Upload wholesale order" data-endpoint="' . esc_url(admin_url('admin-ajax.php')) . '" data-template="' . esc_url($url . 'assets/order-template.xlsx?v=1.0.0') . '" data-login="' . esc_url(wp_login_url(home_url())) . '"><h2>Upload your order</h2><p>Add items from your spreadsheet. We’ll check the SKUs and stock before you confirm.</p><div class="pdou-content"></div><p class="pdou-status" role="status" aria-live="polite" aria-atomic="true"></p></section></dialog><noscript>Please enable JavaScript or use the order form below.</noscript></div>';
});
