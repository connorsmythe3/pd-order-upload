<?php
namespace PureDistilling\OrderUpload;

/** Bounded parsing only. No file extraction, formulas, remote requests or product writes. */
final class Parser {
    public const MAX_BYTES = 256000;
    public const MAX_ROWS = 500;
    public const MAX_QUANTITY = 1000000;
    private const MAX_XML_NODES = 250000;
    private const MAX_XML_ATTRIBUTES = 128;
    private const MAX_XML_TAG_BYTES = 16384;
    private static int $xml_nodes = 0;

    public static function quantity(string $value): ?int {
        $value = trim($value);
        if (!preg_match('/^[0-9]+$/D', $value)) { return null; }
        $value = ltrim($value, '0');
        if ($value === '' || strlen($value) > 7 || (int) $value > self::MAX_QUANTITY) { return null; }
        return (int) $value;
    }

    public static function parse(string $path, string $extension): array {
        $size = is_file($path) ? filesize($path) : false;
        if (!$size || $size > self::MAX_BYTES) { throw new UploadException('Upload a file no larger than 250 KB.'); }
        if (!in_array($extension, ['csv', 'xlsx'], true)) { throw new UploadException('Choose a CSV or Excel .xlsx file.'); }
        self::$xml_nodes = 0;
        $table = $extension === 'csv' ? self::csv($path) : self::xlsx($path);
        if (!$table) { throw new UploadException('The file has no order rows.'); }
        $head = array_shift($table);
        $headers = array_map(static fn($v) => strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', $v['value']))), $head['cells']);
        if (count(array_keys($headers, 'sku', true)) !== 1 || count(array_keys($headers, 'quantity', true)) !== 1) {
            throw new UploadException('Use one SKU column and one Quantity column in the first row.');
        }
        $sku_col = array_search('sku', $headers, true);
        $qty_col = array_search('quantity', $headers, true);
        if (!empty($head['cells'][$sku_col]['formula']) || !empty($head['cells'][$qty_col]['formula']) || !empty($head['cells'][$sku_col]['invalid_type']) || !empty($head['cells'][$qty_col]['invalid_type'])) {
            throw new UploadException('Use plain text SKU and Quantity headers, without formulas.');
        }
        $out = [];
        foreach ($table as $row) {
            $sku_cell = $row['cells'][$sku_col] ?? ['value' => '', 'formula' => false];
            $qty_cell = $row['cells'][$qty_col] ?? ['value' => '', 'formula' => false];
            $sku = trim($sku_cell['value']);
            $quantity = trim($qty_cell['value']);
            // Reference/lookup columns are not order input. Ignore rows whose
            // SKU and quantity are both empty, but still flag input formulas.
            if ($sku === '' && $quantity === '' && !$sku_cell['formula'] && !$qty_cell['formula'] && empty($sku_cell['invalid_type']) && empty($qty_cell['invalid_type'])) { continue; }
            $error = null;
            if ($sku_cell['formula'] || $qty_cell['formula']) { $error = 'Replace formulas with plain SKU and quantity values.'; }
            elseif (!empty($sku_cell['invalid_type']) || !empty($qty_cell['invalid_type'])) { $error = 'Use plain text SKUs and numeric quantities, not Boolean, error or date cells.'; }
            elseif ($sku === '') { $error = 'Enter a SKU.'; }
            elseif (preg_match('/^[+-]?[0-9]+(?:\.[0-9]+)?[eE][+-]?[0-9]+$/D', $sku)) { $error = 'Scientific notation detected. Enter the complete SKU as text.'; }
            elseif (self::quantity($quantity) === null) { $error = 'Quantity must be a positive whole number, up to 1,000,000.'; }
            $out[] = ['row' => $row['row'], 'sku' => $sku, 'quantity' => $quantity, 'error' => $error];
        }
        if (!$out) { throw new UploadException('Add at least one order row below the headers.'); }
        return $out;
    }

    public static function combine(array $rows): array {
        $out = []; $keys = [];
        foreach ($rows as $row) {
            $row['rows'] = $row['rows'] ?? [$row['row']];
            // Prefix prevents PHP converting numeric SKU keys to integers.
            $key = 'sku:' . $row['sku'];
            if ($row['error'] !== null || !isset($keys[$key])) {
                $out[] = $row;
                if ($row['error'] === null) { $keys[$key] = count($out) - 1; }
                continue;
            }
            $i = $keys[$key];
            $sum = (int) $out[$i]['quantity'] + (int) $row['quantity'];
            $out[$i]['rows'] = array_merge($out[$i]['rows'], $row['rows']);
            if (isset($out[$i]['original_quantity']) || isset($row['original_quantity'])) {
                $a = (string) ($out[$i]['original_quantity'] ?? $out[$i]['quantity']);
                $b = (string) ($row['original_quantity'] ?? $row['quantity']);
                $out[$i]['original_quantity'] = self::quantity($a) !== null && self::quantity($b) !== null ? (string) ((int) $a + (int) $b) : $a . ' + ' . $b;
            }
            $out[$i]['quantity'] = (string) $sum;
            if ($sum > self::MAX_QUANTITY) { $out[$i]['error'] = 'Combined quantity exceeds 1,000,000.'; }
        }
        return array_values($out);
    }

    private static function cell(string $value, bool $formula = false): array {
        if (strlen($value) > 512 || !preg_match('//u', $value) || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F]/', $value)) {
            throw new UploadException('A cell contains unsupported text or is longer than 512 bytes. Save as UTF-8 CSV or use the Excel template.');
        }
        return ['value' => $value, 'formula' => $formula];
    }

    private static function csv(string $path): array {
        $handle = fopen($path, 'rb');
        if (!$handle) { throw new UploadException('Unable to read the upload.'); }
        try {
            // fgetcsv locates the first nonblank logical record, including quoted
            // multiline headers. Empty lines have nullable fields on PHP 8.1+.
            $delimiter = ',';
            foreach ([',', ';'] as $candidate) {
                rewind($handle);
                while (($values = fgetcsv($handle, null, $candidate, '"', '')) !== false) {
                    $headers = array_map(static fn($v) => strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', (string) $v))), $values);
                    if (!array_filter($headers, static fn($v) => $v !== '')) { continue; }
                    if (in_array('sku', $headers, true) && in_array('quantity', $headers, true)) { $delimiter = $candidate; }
                    break;
                }
                if ($delimiter === ';') { break; }
            }
            rewind($handle); $out = []; $row = 0; $columns = null;
            while (($values = fgetcsv($handle, null, $delimiter, '"', '')) !== false) {
                ++$row;
                if (count($values) > 256) { throw new UploadException('Use no more than 256 columns.'); }
                $nonblank = false; $cells = [];
                foreach ($values as $column => $value) {
                    // Validate every field, but retain only imported columns once
                    // headers are known. One record's unused values die each loop.
                    $value = (string) $value;
                    if ($columns === null) { $value = preg_replace('/^\xEF\xBB\xBF/', '', $value); }
                    $cell = self::cell($value);
                    if (trim($cell['value']) !== '') { $nonblank = true; }
                    if ($columns === null || in_array($column, $columns, true)) { $cells[$column] = $cell; }
                }
                if (!$nonblank) { continue; }
                if ($columns === null) {
                    $headers = array_map(static fn($v) => strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', $v['value']))), $cells);
                    if (count(array_keys($headers, 'sku', true)) !== 1 || count(array_keys($headers, 'quantity', true)) !== 1) {
                        throw new UploadException('Use one SKU column and one Quantity column in the first row.');
                    }
                    $columns = array_keys(array_filter($headers, static fn($v) => $v === 'sku' || $v === 'quantity'));
                }
                $out[] = ['row' => $row, 'cells' => $cells];
                if (count($out) > self::MAX_ROWS + 1) { throw new UploadException('Upload no more than 500 nonblank order rows.'); }
            }
            return $out;
        } finally { fclose($handle); }
    }

    /** Bound start tags before libxml encounters a quadratic attribute workload. */
    private static function xml_preflight(string $data): void {
        if (strlen($data) > 5242880 || stripos($data, '<!DOCTYPE') !== false || stripos($data, '<!ENTITY') !== false || strpos($data, "\0") !== false) {
            throw new UploadException('Unsupported or unsafe Excel XML content.', 'suspicious');
        }
        // XML components must be UTF-8 (optional BOM) or ASCII. Other encoding
        // declarations are rejected before native decoding, including DTD tricks.
        if (!preg_match('//u', $data) || (preg_match('/<\?xml\s[^?]*encoding\s*=\s*([\'"])(.*?)\1/i', $data, $encoding) && !in_array(strtoupper($encoding[2]), ['UTF-8', 'UTF8', 'US-ASCII'], true))) {
            throw new UploadException('Unsupported Excel XML encoding. Save the workbook as standard UTF-8 .xlsx.');
        }
        $offset = 0; $length = strlen($data);
        while (($start = strpos($data, '<', $offset)) !== false) {
            $terminator = null; $prefix = substr($data, $start, 9);
            if (str_starts_with($prefix, '<!--')) { $terminator = '-->'; }
            elseif ($prefix === '<![CDATA[') { $terminator = ']]>'; }
            elseif (str_starts_with($prefix, '<?')) { $terminator = '?>'; }
            if ($terminator !== null) {
                $end = strpos($data, $terminator, $start + 2);
                if ($end === false) { throw new UploadException('The Excel file contains malformed XML.'); }
                $offset = $end + strlen($terminator); continue;
            }
            if (str_starts_with($prefix, '<!')) { throw new UploadException('Unsupported or unsafe Excel XML declaration.', 'suspicious'); }
            $quote = ''; $attributes = 0; $end = $start + 1;
            for (; $end < $length; ++$end) {
                if ($end - $start >= self::MAX_XML_TAG_BYTES) { throw new UploadException('This Excel XML tag is too complex. Copy SKU and Quantity into the template.'); }
                $char = $data[$end];
                if ($quote !== '') { if ($char === $quote) { $quote = ''; } continue; }
                if ($char === '"' || $char === "'") { $quote = $char; }
                elseif ($char === '=' && ++$attributes > self::MAX_XML_ATTRIBUTES) { throw new UploadException('This Excel XML tag is too complex. Copy SKU and Quantity into the template.'); }
                elseif ($char === '>') { break; }
            }
            if ($end === $length) { throw new UploadException('The Excel file contains malformed XML.'); }
            $offset = $end + 1;
        }
    }

    private static function xml(string $data): \XMLReader {
        self::xml_preflight($data);
        $r = new \XMLReader();
        if (!$r->XML($data, null, LIBXML_NONET | LIBXML_COMPACT)) { throw new UploadException('Invalid Excel XML.'); }
        $r->setParserProperty(\XMLReader::LOADDTD, false);
        $r->setParserProperty(\XMLReader::SUBST_ENTITIES, false);
        $r->setParserProperty(\XMLReader::VALIDATE, false);
        return $r;
    }

    /** Every reader shares a request budget, including re-reading cell fragments. */
    private static function read(\XMLReader $r): bool {
        $ok = $r->read();
        if (++self::$xml_nodes > self::MAX_XML_NODES || ($ok && $r->depth > 16)) {
            throw new UploadException('This Excel file is too complex. Copy SKU and Quantity into the template.');
        }
        if ($ok && $r->nodeType === \XMLReader::DOC_TYPE) { throw new UploadException('Unsupported or unsafe Excel DTD.', 'suspicious'); }
        // Fail immediately: do not accumulate parser warnings from malformed documents.
        if (libxml_get_errors()) { throw new UploadException('The Excel file contains malformed XML.'); }
        return $ok;
    }

    /** Bound actual decompressed bytes, verify declared length and CRC; never extract. */
    private static function part(\ZipArchive $z, string $name): string {
        $stat = $z->statName($name);
        if (!$stat || $stat['size'] > 5242880) { throw new UploadException('Invalid Excel component.'); }
        $stream = @$z->getStream($name);
        if (!is_resource($stream)) { throw new UploadException('Unable to read an Excel component.'); }
        $data = ''; $crc = hash_init('crc32b');
        try {
            while (!feof($stream)) {
                $chunk = @fread($stream, 8192);
                if ($chunk === false || ($chunk === '' && !feof($stream))) { throw new UploadException('The Excel archive is damaged.'); }
                if (strlen($data) + strlen($chunk) > 5242880) { throw new UploadException('The expanded Excel component is too large.'); }
                $data .= $chunk; hash_update($crc, $chunk);
            }
        } finally { fclose($stream); }
        if (strlen($data) !== $stat['size'] || strtolower(hash_final($crc)) !== sprintf('%08x', $stat['crc'])) {
            throw new UploadException('The Excel archive failed its integrity check.');
        }
        return $data;
    }

    private static function content_types(string $data): void {
        $r = self::xml($data); $default = ''; $override = null; $root = false;
        while (self::read($r)) {
            if ($r->nodeType !== \XMLReader::ELEMENT) { continue; }
            if ($r->depth === 0) {
                $root = $r->localName === 'Types' && $r->namespaceURI === 'http://schemas.openxmlformats.org/package/2006/content-types';
                if (!$root) { throw new UploadException('Invalid Excel content types.'); }
            }
            $type = (string) $r->getAttribute('ContentType');
            if (preg_match('~macro|vba|activex|oleobject|externalLink|connections~i', $type)) {
                throw new UploadException('Remove macros, embedded objects and external data connections from this workbook.', 'suspicious');
            }
            if ($r->localName === 'Default' && $r->getAttribute('Extension') === 'xml') { $default = $type; }
            if ($r->localName === 'Override' && $r->getAttribute('PartName') === '/xl/workbook.xml') { $override = $type; }
        }
        $r->close();
        if (!$root || ($override ?? $default) !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml') { throw new UploadException('Use a standard .xlsx workbook without macros.', 'suspicious'); }
    }

    private static function xlsx(string $path): array {
        if (!class_exists('ZipArchive') || !class_exists('XMLReader')) { throw new UploadException('Excel uploads need PHP ZIP and XMLReader. Ask the site administrator.'); }
        $z = new \ZipArchive();
        if ($z->open($path, \ZipArchive::CHECKCONS) !== true) { throw new UploadException('The Excel file is damaged or is not an .xlsx workbook.'); }
        $previous = libxml_use_internal_errors(true);
        try {
            $names = []; $total = 0;
            if ($z->numFiles > 1000) { throw new UploadException('This Excel file contains too many components.'); }
            for ($i = 0; $i < $z->numFiles; ++$i) {
                $s = $z->statIndex($i);
                if (!$s) { throw new UploadException('Invalid Excel archive entry.'); }
                $name = $s['name'];
                if (isset($names[$name]) || strlen($name) > 240 || preg_match('~(^/|\\\\|:|//|(?:^|/)\.{1,2}(?:/|$)|[\x00-\x1F])~', $name) || preg_match('~(?:^|/)(?:embeddings|activeX|externalLinks|macrosheets|dialogsheets)(?:/|$)|vba|connections\.xml$~i', $name) || !empty($s['encryption_method']) || !in_array($s['comp_method'], [\ZipArchive::CM_STORE, \ZipArchive::CM_DEFLATE], true)) { throw new UploadException('Unsupported or unsafe Excel archive.', 'suspicious'); }
                if (!str_ends_with($name, '/') && !preg_match('~\.(?:xml|rels|png|jpe?g|gif|bmp|emf|wmf)$~i', $name)) {
                    $printer_settings = preg_match('~^xl/printerSettings/printerSettings[0-9]+\.bin$~i', $name);
                    $executable = preg_match('~\.(?:php[0-9]*|phtml|phar|exe|dll|js|sh|bin)$~i', $name);
                    throw new UploadException('Remove unsupported embedded files from this Excel workbook.', $executable && !$printer_settings ? 'suspicious' : 'validation');
                }
                $opsys = 0; $attributes = 0;
                if (!$z->getExternalAttributesIndex($i, $opsys, $attributes) || ($opsys === \ZipArchive::OPSYS_UNIX && (($attributes >> 16) & 0170000) === 0120000)) { throw new UploadException('Unsupported Excel archive attributes.', 'suspicious'); }
                $names[$name] = true; $total += $s['size'];
                if ($s['size'] > 5242880 || $total > 20971520) { throw new UploadException('The expanded Excel file is too large.'); }
                if (preg_match('~\.rels$~i', $name)) {
                    $r = self::xml(self::part($z, $name));
                    while (self::read($r)) {
                        if ($r->nodeType === \XMLReader::ELEMENT && $r->localName === 'Relationship' && strcasecmp((string) $r->getAttribute('TargetMode'), 'External') === 0) {
                            $hyperlink = (string) $r->getAttribute('Type') === 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink';
                            throw new UploadException('Remove external links from this Excel file.', $hyperlink ? 'validation' : 'suspicious');
                        }
                    }
                    $r->close();
                } elseif (preg_match('~\.xml$~i', $name)) {
                    $r = self::xml(self::part($z, $name));
                    while (self::read($r)) { /* All components share structural budgets, even when unused. */ }
                    $r->close();
                }
            }
            foreach (['[Content_Types].xml', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels'] as $name) {
                if (!isset($names[$name])) { throw new UploadException('The file is not a supported .xlsx workbook.'); }
            }
            self::content_types(self::part($z, '[Content_Types].xml'));
            $r = self::xml(self::part($z, 'xl/workbook.xml')); $first = ''; $sheet_seen = false;
            while (self::read($r)) {
                if (!$sheet_seen && $r->nodeType === \XMLReader::ELEMENT && $r->localName === 'sheet') { $sheet_seen = true; $first = (string) $r->getAttributeNs('id', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'); }
            }
            $r->close(); $target = '';
            $r = self::xml(self::part($z, 'xl/_rels/workbook.xml.rels'));
            while (self::read($r)) {
                if ($r->nodeType === \XMLReader::ELEMENT && $r->localName === 'Relationship' && $r->getAttribute('Id') === $first && str_ends_with((string) $r->getAttribute('Type'), '/worksheet')) { $target = (string) $r->getAttribute('Target'); }
            }
            $r->close();
            if ($target === '' || preg_match('~(^[a-z]+:|\\\\|(?:^|/)\.\.(?:/|$))~i', $target)) { throw new UploadException('Invalid Excel worksheet reference.', 'suspicious'); }
            $target = str_starts_with($target, '/') ? ltrim($target, '/') : 'xl/' . $target;
            if (!isset($names[$target])) { throw new UploadException('The first worksheet is missing.'); }
            $strings = [];
            if (isset($names['xl/sharedStrings.xml'])) {
                $r = self::xml(self::part($z, 'xl/sharedStrings.xml'));
                while (self::read($r)) {
                    if ($r->nodeType === \XMLReader::ELEMENT && $r->localName === 'si') {
                        $strings[] = self::text($r->readOuterXml());
                        if (count($strings) > 100000) { throw new UploadException('Too many Excel text values.'); }
                    }
                }
                $r->close();
            }
            $out = []; $count = 0; $seen_rows = []; $previous_row = 0; $ranges = [];
            $r = self::xml(self::part($z, $target));
            while (self::read($r)) {
                if ($r->nodeType !== \XMLReader::ELEMENT || $r->localName !== 'row') { continue; }
                $row_coordinate = $r->getAttribute('r');
                if ($row_coordinate !== null && !ctype_digit($row_coordinate)) { throw new UploadException('Unsupported Excel row layout.'); }
                $row_xml = $r->readOuterXml();
                $row = $row_coordinate === null ? self::inferred_row($row_xml, $previous_row + 1) : (int) $row_coordinate;
                if ($row < 1 || $row > 10000 || isset($seen_rows[$row])) { throw new UploadException('Unsupported Excel row layout.'); }
                $seen_rows[$row] = true; $previous_row = $row; $cells = []; $previous_column = -1;
                $rr = self::xml($row_xml);
                while (self::read($rr)) {
                    if ($rr->nodeType !== \XMLReader::ELEMENT || $rr->localName !== 'c') { continue; }
                    if (++$count > 100000) { throw new UploadException('Too many Excel cells.'); }
                    $coordinate = $rr->getAttribute('r');
                    if ($coordinate === null) { $column = $previous_column + 1; }
                    else {
                        [$column, $cell_row] = self::coordinate($coordinate);
                        if ($cell_row !== $row) { throw new UploadException('Invalid Excel cell coordinate.'); }
                    }
                    $previous_column = $column;
                    if ($column > 255 || isset($cells[$column])) { throw new UploadException('Use no more than 256 columns and no duplicate cells.'); }
                    $type = (string) $rr->getAttribute('t'); $value = ''; $formula = false;
                    $cr = self::xml($rr->readOuterXml());
                    while (self::read($cr)) {
                        if ($cr->nodeType !== \XMLReader::ELEMENT) { continue; }
                        if ($cr->localName === 'f') {
                            $formula = true; $ref = (string) $cr->getAttribute('ref');
                            if ($ref !== '') {
                                $bounds = explode(':', $ref);
                                if (count($bounds) > 2) { throw new UploadException('Unsupported Excel formula range.'); }
                                [$left, $top] = self::coordinate($bounds[0]);
                                [$right, $bottom] = self::coordinate($bounds[1] ?? $bounds[0]);
                                if ($right < $left || $bottom < $top) { throw new UploadException('Unsupported Excel formula range.'); }
                                $ranges[] = [$left, $top, $right, $bottom];
                            }
                        }
                        elseif ($cr->localName === 'v') { $value = $cr->readString(); }
                        elseif ($type === 'inlineStr' && $cr->localName === 'is') { $value = self::text($cr->readOuterXml()); }
                    }
                    $cr->close();
                    if ($type === 's') {
                        if (!ctype_digit($value) || !isset($strings[(int) $value])) { throw new UploadException('Invalid Excel text reference.'); }
                        $value = $strings[(int) $value];
                    }
                    $cells[$column] = self::cell($value, $formula);
                    $cells[$column]['invalid_type'] = !in_array($type, ['', 'n', 's', 'str', 'inlineStr'], true);
                }
                $rr->close();
                if (!array_filter($cells, static fn($v) => trim($v['value']) !== '' || $v['formula'] || !empty($v['invalid_type']))) { continue; }
                $out[] = ['row' => $row, 'cells' => $cells];
                if (count($out) > self::MAX_ROWS + 1) { throw new UploadException('Upload no more than 500 nonblank order rows.'); }
            }
            $r->close();
            if (libxml_get_errors()) { throw new UploadException('The Excel file contains malformed XML.'); }
            self::mark_formula_ranges($out, $ranges);
            return $out;
        } finally { $z->close(); libxml_clear_errors(); libxml_use_internal_errors($previous); }
    }

    /** Row r is optional; an explicit cell coordinate establishes a sparse row. */
    private static function inferred_row(string $xml, int $fallback): int {
        $r = self::xml($xml);
        try {
            while (self::read($r)) {
                if ($r->nodeType !== \XMLReader::ELEMENT || $r->localName !== 'c') { continue; }
                $coordinate = $r->getAttribute('r');
                if ($coordinate !== null) { return self::coordinate($coordinate)[1]; }
            }
            return $fallback;
        } finally { $r->close(); }
    }

    /** Restrict all inferred/range coordinates to the existing worksheet bounds. */
    private static function coordinate(string $coordinate): array {
        if (!preg_match('/^([A-Z]{1,3})([0-9]+)$/D', $coordinate, $match)) { throw new UploadException('Invalid Excel cell coordinate.'); }
        $column = 0;
        foreach (str_split($match[1]) as $letter) { $column = $column * 26 + ord($letter) - 64; }
        $row = (int) $match[2];
        if ($column > 256 || $row < 1 || $row > 10000) { throw new UploadException('Unsupported Excel coordinate bounds.'); }
        return [$column - 1, $row];
    }

    /** Union formula ranges only for imported columns, avoiding range expansion. */
    private static function mark_formula_ranges(array &$table, array $ranges): void {
        if (!$table || !$ranges) { return; }
        foreach ($table[0]['cells'] as $column => $cell) {
            if (!in_array(strtolower(trim(preg_replace('/^\xEF\xBB\xBF/', '', $cell['value']))), ['sku', 'quantity'], true)) { continue; }
            $intervals = [];
            foreach ($ranges as [$left, $top, $right, $bottom]) {
                if ($column >= $left && $column <= $right) { $intervals[] = [$top, $bottom]; }
            }
            if (!$intervals) { continue; }
            usort($intervals, static fn($a, $b) => $a[0] <=> $b[0]); $merged = [];
            foreach ($intervals as $interval) {
                $last = count($merged) - 1;
                if ($last >= 0 && $interval[0] <= $merged[$last][1] + 1) { $merged[$last][1] = max($merged[$last][1], $interval[1]); }
                else { $merged[] = $interval; }
            }
            foreach ($table as &$row) {
                $low = 0; $high = count($merged) - 1;
                while ($low <= $high) {
                    $mid = intdiv($low + $high, 2);
                    if ($row['row'] < $merged[$mid][0]) { $high = $mid - 1; }
                    elseif ($row['row'] > $merged[$mid][1]) { $low = $mid + 1; }
                    else {
                        $row['cells'][$column] = $row['cells'][$column] ?? self::cell('');
                        $row['cells'][$column]['formula'] = true; break;
                    }
                }
            }
            unset($row);
        }
    }

    private static function text(string $xml): string {
        $r = self::xml($xml); $value = ''; $phonetic_depth = null;
        while (self::read($r)) {
            if ($r->nodeType === \XMLReader::ELEMENT && $r->localName === 'rPh' && !$r->isEmptyElement) { $phonetic_depth = $r->depth; }
            elseif ($r->nodeType === \XMLReader::END_ELEMENT && $r->localName === 'rPh' && $r->depth === $phonetic_depth) { $phonetic_depth = null; }
            elseif ($phonetic_depth === null && $r->nodeType === \XMLReader::ELEMENT && $r->localName === 't') { $value .= $r->readString(); }
        }
        $r->close(); return self::cell($value)['value'];
    }
}
