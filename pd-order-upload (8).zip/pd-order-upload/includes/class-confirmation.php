<?php
namespace PureDistilling\OrderUpload;

/** Durable batches. An unfinished mutation batch is uncertain, never replayable. */
final class Confirmation {
    public const BATCH_ROWS = 50;
    private const SECONDS = 4.0;
    private static array $partial = [];
    public static function partial(): array { return self::$partial; }
    public static function start(string $token, int $version, array $selected): array {
        self::$partial = [];
        $r = ReviewStore::get($token);
        if ($r['state'] === 'done') { return $r['result']; }
        if ($r['state'] === 'review') {
            if ($r['version'] !== $version || !$selected || count($selected) > Parser::MAX_ROWS) { throw new UploadException('Review the selected quantities before adding them.'); }
            $source = array_column($r['rows'], null, 'id'); $seen = [];
            foreach ($selected as $id) {
                if (!is_string($id) || isset($seen[$id]) || !isset($source[$id]) || !$source[$id]['eligible'] || !$source[$id]['selected'] || $source[$id]['accepted'] < 1) { throw new UploadException('Select only ready rows with quantities you have accepted.'); }
                $seen[$id] = true;
            }
            ReviewStore::begin($token, $selected);
        } elseif ($r['version'] !== $version || ($r['progress']['selected'] ?? null) !== $selected) {
            throw new UploadException('This confirmation has a different selection. Check your cart.');
        }
        return self::advance($token, $version);
    }
    public static function status(array $r): array {
        $p = $r['progress'] ?? [];
        $check=!empty($p['needs_check']) || !empty($p['batch']) || !$p || ($r['expires']??0)<=time();
        return ['completed'=>(int)($p['cursor'] ?? 0), 'total'=>count($p['selected'] ?? []),
            'needs_check'=>$check,
            'message'=>$check
                ? 'Ordering was interrupted. Some items may already be in your cart. Check your cart before starting another upload.'
                : 'Your order is being added in smaller groups.'];
    }
    public static function advance(string $token, int $version): array {
        self::$partial = [];
        $r = ReviewStore::get($token);
        if ($r['state'] === 'done') { return $r['result']; }
        if ($r['state'] !== 'processing' || $r['version'] !== $version) { throw new UploadException('Refresh the review before continuing.'); }
        $p = $r['progress'] ?? null;
        if (self::status($r)['needs_check']) { return ['progress'=>self::status($r)]; }
        ReviewStore::retire_origin($r);
        if (class_exists(CartGuard::class)) { CartGuard::assert_owned(); }
        $source = array_column($r['rows'], null, 'id');
        $batch = array_slice($p['selected'], $p['cursor'], self::BATCH_ROWS);
        $p['batch'] = $batch;
        ReviewStore::progress($token, $p); // Durable intent BEFORE any cart mutation.
        $core = self::defer_core(); $items = []; $started = microtime(true); Validator::use_cart_cache(true);
        try {
            foreach ($batch as $id) {
                if ($items && microtime(true)-$started >= self::SECONDS) { break; }
                $items[] = self::add($source[$id]);
                self::$partial = array_merge($p['items'], $items);
            }
            if (class_exists(CartGuard::class)) { CartGuard::assert_owned(); }
            // Core writes are deferred only inside this request; external hooks stay active.
            WC()->cart->calculate_totals();
            if (is_callable([WC()->cart, 'set_session'])) { WC()->cart->set_session(); }
            foreach ($core as $entry) {
                if ($entry['method'] === 'persistent_cart_update') { call_user_func($entry['callback']); }
            }
            if (is_callable([WC()->session, 'save_data'])) { WC()->session->save_data(); }
            self::verify_saved_cart();
            $cart = WC()->cart->get_cart();
            foreach ($items as &$item) {
                if (($item['added'] ?? 0) > 0 && isset($cart[$item['key'] ?? ''])) { $item['price'] = Pricing::actual($cart[$item['key']]); }
            }
            unset($item);
            $p['items'] = array_merge($p['items'], $items); $p['cursor'] += count($items); $p['batch'] = [];
            ReviewStore::progress($token, $p); // Cart persisted before confirmed progress.
            if ($p['cursor'] >= count($p['selected'])) {
                return self::finish($token, ReviewStore::get($token), $p['items']);
            }
            return ['progress'=>self::status(ReviewStore::get($token))];
        } catch (\Throwable $e) {
            $p['needs_check'] = true;
            try { ReviewStore::progress($token, $p); } catch (\Throwable $ignored) { /* Stored intent remains conservative. */ }
            if (!self::$partial) { self::$partial = array_merge($p['items'], $items); }
            return ['progress'=>self::status(ReviewStore::get($token))];
        } finally { self::restore_core($core); Validator::use_cart_cache(false); }
    }
    private static function add(array $row): array {
        $pid = (int)$row['product_id']; $q = (int)$row['accepted'];
        $out = ['id'=>$row['id'], 'rows'=>$row['rows'], 'sku'=>$row['sku'], 'name'=>$row['name'], 'requested'=>$row['requested'], 'accepted'=>$q, 'added'=>0,
            'price'=>['known'=>false,'unit_ex_tax'=>null,'bulk_applied'=>false]];
        $p = wc_get_product($pid);
        $state = $p && $p->get_sku() === $row['sku'] ? Validator::check($pid,$q)
            : ['eligible'=>false,'status'=>'unavailable','reason'=>'This item is not available to your account.','available'=>null];
        if (!$state['eligible']) { unset($state['eligible']); return array_merge($out,$state); }
        $before = Validator::cart_quantity((int)$p->get_stock_managed_by_id()); $key = false;
        $guard = static function($filtered,$id) use($pid,$q) {
            if ((int)$id !== $pid) { return $filtered; }
            // Recheck after third-party quantity filters; never permit silent alteration.
            Validator::invalidate_cart_cache();
            return is_numeric($filtered) && (float)$filtered === (float)$q && Validator::check($pid,$q)['eligible'] ? $q : 0;
        };
        $offset = count(wc_get_notices('error'));
        try {
            if (!apply_filters('woocommerce_add_to_cart_validation',true,$pid,$q,0,[])) { $state=['status'=>'rejected','reason'=>self::notice($offset),'available'=>$state['available']]; }
            else {
                add_filter('woocommerce_add_to_cart_quantity',$guard,PHP_INT_MAX,2);
                $key = WC()->cart->add_to_cart($pid,$q);
                if (!$key) { $state=['status'=>'rejected','reason'=>self::notice($offset),'available'=>$state['available']]; }
            }
        } catch (\Throwable $e) { $state=['status'=>'rejected','reason'=>'The item could not be added normally. Check your cart before retrying.','available'=>$state['available']]; }
        finally { remove_filter('woocommerce_add_to_cart_quantity',$guard,PHP_INT_MAX); Validator::invalidate_cart_cache(); }
        try { $added = max(0,Validator::cart_quantity((int)$p->get_stock_managed_by_id())-$before); }
        catch (\Throwable $e) {
            $out['added']=null;$out['status']='uncertain';$out['reason']='Addition was attempted but its quantity could not be verified. Check your cart.';
            self::$partial[]=$out;throw $e;
        }
        if ($added>0) { $out['added']=(int)$added; $out['key']=$key; $state=['status'=>'added','reason'=>'Added to cart.','available'=>$state['available']]; }
        unset($state['eligible']); return array_merge($out,$state);
    }
    private static function notice(int $offset): string {
        $notices=array_slice(wc_get_notices('error'),$offset);
        $message=isset($notices[0]['notice'])?wp_strip_all_tags($notices[0]['notice']):'';
        return $message!==''?wp_html_excerpt($message,500,''):'This quantity did not pass the store’s ordering rules. Adjust it or use the normal order form.';
    }
    private static function finish(string $token, array $r, array $items): array {
        $cart=WC()->cart->get_cart();
        foreach ($items as &$item) {
            if (($item['added']??0)>0) {
                $item['price']=isset($cart[$item['key']??'']) ? Pricing::actual($cart[$item['key']]) : ['known'=>false,'unit_ex_tax'=>null,'bulk_applied'=>false];
            }
            unset($item['key']);
        }
        unset($item);
        $seen=array_fill_keys(array_column($items,'id'),true);
        foreach ($r['rows'] as $row) {
            if (isset($seen[$row['id']])) { continue; }
            $items[]=['id'=>$row['id'],'rows'=>$row['rows'],'sku'=>$row['sku'],'name'=>$row['name'],'requested'=>$row['requested'],'accepted'=>0,'added'=>0,
                'status'=>$row['eligible']?'excluded':$row['status'],'reason'=>$row['eligible']?'Not selected. This item was not added.':$row['reason'],
                'price'=>['known'=>false,'unit_ex_tax'=>null,'bulk_applied'=>false]];
        }
        $result=['items'=>$items,'cart_url'=>wc_get_cart_url(),'currency'=>get_woocommerce_currency(),'cart_hash'=>WC()->cart->get_cart_hash()];
        ReviewStore::finish($token,$result); return $result;
    }
    public static function recover(string $token, bool $acknowledged): array {
        $r=ReviewStore::get($token);
        if ($r['state']==='done') { return $r['result']; }
        if (!$acknowledged || $r['state']!=='processing' || !self::status($r)['needs_check']) { throw new UploadException('Check your cart before acknowledging an interrupted order.'); }
        $p=$r['progress']??[]; $items=$p['items']??[]; $seen=array_fill_keys(array_column($items,'id'),true);
        $selected=array_fill_keys($p['selected']??array_column($r['rows'],'id'),true);
        $uncertain=array_fill_keys($p['batch']??array_column($r['rows'],'id'),true);
        foreach ($r['rows'] as $row) {
            if (isset($seen[$row['id']]) || !isset($selected[$row['id']])) { continue; }
            $unknown=isset($uncertain[$row['id']]);
            $items[]=['id'=>$row['id'],'rows'=>$row['rows'],'sku'=>$row['sku'],'name'=>$row['name'],'requested'=>$row['requested'],'accepted'=>$row['accepted'],
                'added'=>$unknown?null:0,'status'=>$unknown?'uncertain':'excluded',
                'reason'=>$unknown?'Addition could not be verified. Check the quantity in your cart.':'Not processed after interruption.',
                'price'=>['known'=>false,'unit_ex_tax'=>null,'bulk_applied'=>false]];
        }
        return self::finish($token,$r,$items);
    }
    private static function defer_core(): array {
        global $wp_filter; $removed=[];
        foreach (['woocommerce_add_to_cart','woocommerce_cart_updated'] as $hook) {
            foreach (($wp_filter[$hook]->callbacks ?? []) as $priority=>$callbacks) {
                foreach ($callbacks as $c) {
                    $fn=$c['function'];
                    if (!is_array($fn) || !is_object($fn[0])) { continue; }
                    $class=get_class($fn[0]); $method=$fn[1];
                    if (!(($class==='WC_Cart' && $method==='calculate_totals') || ($class==='WC_Cart_Session' && $method==='persistent_cart_update'))) { continue; }
                    remove_action($hook,$fn,$priority);
                    $removed[]=['hook'=>$hook,'callback'=>$fn,'priority'=>$priority,'args'=>$c['accepted_args'],'method'=>$method];
                }
            }
        }
        return $removed;
    }
    private static function restore_core(array $entries): void {
        foreach ($entries as $e) { add_action($e['hook'],$e['callback'],$e['priority'],$e['args']); }
    }
    private static function verify_saved_cart(): void {
        // Read through the Woo session handler, not its loaded in-memory session.
        if (!is_callable([WC()->session,'get_session']) || !is_callable([WC()->session,'get_customer_id'])) { return; }
        global $wpdb;
        if (!(WC()->session instanceof \WC_Session_Handler)) { throw new UploadException('This cart session handler needs compatibility verification. Check your cart.'); }
        // Woo's get_session() may return the cache populated by a failed SQL write.
        // Verify the standard handler's persisted row directly, bypassing that cache.
        $raw=$wpdb->get_var($wpdb->prepare('SELECT session_value FROM '.$wpdb->prefix.'woocommerce_sessions WHERE session_key = %s',WC()->session->get_customer_id()));
        $saved=maybe_unserialize($raw);
        if (!is_array($saved) || !isset($saved['cart'])) { throw new UploadException('Saved cart could not be verified. Check your cart.'); }
        $actual=function_exists('maybe_unserialize')?maybe_unserialize($saved['cart']):$saved['cart'];
        $expected=WC()->cart->get_cart_for_session();
        if ($actual!==$expected) { throw new UploadException('Saved cart differs from the confirmed cart. Check your cart.'); }
    }
}
