<?php
namespace PureDistilling\OrderUpload;
/** Classic reCAPTCHA v2 checkbox. Secret stays in a non-autoloaded option. */
final class Captcha {
    private static function key($v): string { return is_string($v) && preg_match('/^[A-Za-z0-9_-]{20,200}$/D', trim($v)) ? trim($v) : ''; }
    public static function settings(): array {
        $r = get_option('pdou_captcha_settings', []);
        return self::validate_settings(is_array($r) ? $r : []);
    }
    public static function validate_settings(array $input, array $old = []): array {
        $site = array_key_exists('site_key', $input) ? self::key($input['site_key']) : self::key($old['site_key'] ?? '');
        $secret = self::key($old['secret_key'] ?? '');
        if (is_string($input['secret_key'] ?? null) && trim($input['secret_key']) !== '') { $secret = self::key($input['secret_key']); }
        if (!empty($input['clear_secret'])) { $secret = ''; }
        return ['enabled' => !empty($input['enabled']), 'site_key' => $site, 'secret_key' => $secret];
    }
    public static function public_config(): array { $r = self::settings(); return ['enabled' => $r['enabled'], 'site_key' => $r['site_key']]; }
    public static function verify($token): void {
        $cfg = self::settings();
        if (!$cfg['enabled']) { return; }
        if ($cfg['site_key'] === '' || $cfg['secret_key'] === '') { throw new UploadException('Human verification is unavailable. Please use the order form or contact us.'); }
        if (!is_string($token) || strlen($token) > 8192 || strlen($token) < 20 || preg_match('/[\x00-\x20\x7F]/', $token)) { throw new UploadException('Complete the “I’m not a robot” check before uploading.'); }
        try {
            $response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', ['timeout'=>10, 'redirection'=>0, 'limit_response_size'=>8192, 'body'=>['secret'=>$cfg['secret_key'], 'response'=>$token]]);
            if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) { throw new \RuntimeException('Verification service unavailable'); }
            $body = wp_remote_retrieve_body($response);
            if (!is_string($body) || strlen($body) > 8192) { throw new \RuntimeException('Invalid response'); }
            $result = json_decode($body, true, 10, JSON_THROW_ON_ERROR);
        } catch (\Throwable $e) { throw new UploadException('Human verification could not be checked. Please try again or use the order form.'); }
        $hosts = [];
        foreach ([home_url(), admin_url()] as $url) { $host = wp_parse_url($url, PHP_URL_HOST); if (is_string($host)) { $hosts[] = strtolower(rtrim($host, '.')); } }
        $host = is_string($result['hostname'] ?? null) ? strtolower(rtrim($result['hostname'], '.')) : '';
        if (!is_array($result) || ($result['success'] ?? null) !== true || !in_array($host, $hosts, true)) { throw new UploadException('Human verification failed or expired. Complete the check again.'); }
    }
}
