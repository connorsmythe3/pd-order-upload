<?php
namespace PureDistilling\OrderUpload;
/** Small durable queue; never performs SMTP in an upload/cart request. */
final class AlertQueue {
    public static function register(): void { add_action('pdou_alert_queue', [self::class, 'run']); }
    private static array $lease = [];
    private static function remove_lease($lease): void {
        global $wpdb;
        $wpdb->query($wpdb->prepare('DELETE FROM '.$wpdb->options.' WHERE option_name = %s AND option_value = %s',
            'pdou_alert_queue_lock', maybe_serialize($lease)));
        wp_cache_delete('pdou_alert_queue_lock','options');
    }
    private static function lock(): bool {
        $old=get_option('pdou_alert_queue_lock',null);
        $expiry=is_array($old) ? ($old['expires']??0) : (int)$old;
        if ($old!==null && $expiry<time()) { self::remove_lease($old); }
        // Only short queue mutations hold this lease; SMTP runs after releasing it.
        $lease=['owner'=>bin2hex(random_bytes(16)),'expires'=>time()+3600];
        global $wpdb;
        if ($wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", 'pdou_alert_queue_lock', maybe_serialize($lease))) !== 1) { return false; }
        wp_cache_delete('pdou_alert_queue_lock','options');
        wp_cache_delete('notoptions','options');
        // Another worker may enqueue while this worker releases the mutex for SMTP.
        // Refresh the per-request option cache every time ownership is reacquired.
        wp_cache_delete('pdou_alert_jobs','options');
        self::$lease=$lease; return true;
    }
    private static function unlock(): void { if (self::$lease) { self::remove_lease(self::$lease); self::$lease=[]; } }
    public static function enqueue(int $uid, string $recipient, string $body): bool {
        if (!self::lock()) { update_option('pdou_alert_failed', time(), false); return false; }
        try {
            $jobs = get_option('pdou_alert_jobs', []); if (!is_array($jobs)) { $jobs = []; }
            if (count($jobs)>=100 && !isset($jobs[$uid])) { update_option('pdou_alert_failed', time(), false); return false; }
            if (!isset($jobs[$uid])) { $jobs[$uid] = ['to'=>$recipient,'body'=>AuditLog::text($body,4000),'attempts'=>0,'due'=>time(),'expires'=>time()+3600]; }
            if (!update_option('pdou_alert_jobs',$jobs,false) && get_option('pdou_alert_jobs')!==$jobs) { update_option('pdou_alert_failed',time(),false); return false; }
            self::schedule(time()+1); return true;
        } finally { self::unlock(); }
    }
    private static function schedule(int $at): void {
        $next=wp_next_scheduled('pdou_alert_queue');
        if ($next && $next>$at) { wp_unschedule_event($next,'pdou_alert_queue'); $next=false; }
        if (!$next) {
            if (!wp_schedule_single_event($at,'pdou_alert_queue')) { update_option('pdou_alert_failed',time(),false); }
        }
    }
    public static function run(): void {
        if (!self::lock()) { self::schedule(time()+120); return; }
        try {
            $jobs = get_option('pdou_alert_jobs',[]); if (!is_array($jobs)) { $jobs=[]; }
            $start=microtime(true); $processed=0;
            foreach ($jobs as $uid=>$job) {
                if (!isset($jobs[$uid])) { continue; }
                $job=$jobs[$uid];
                if ((int)$job['expires']<time() || (int)$job['attempts']>=3) { unset($jobs[$uid]); update_option('pdou_alert_failed',time(),false); continue; }
                if ((int)$job['due']>time()) { continue; }
                // Reserve attempt durably before SMTP; a crashed worker cannot retry forever.
                ++$job['attempts']; $job['due']=time()+300*$job['attempts']; $jobs[$uid]=$job;
                if (!update_option('pdou_alert_jobs',$jobs,false) && get_option('pdou_alert_jobs')!==$jobs) { update_option('pdou_alert_failed',time(),false); break; }
                self::schedule($job['due']); // Recover a worker killed during SMTP.
                self::unlock();
                $ok=false;
                try { $ok=wp_mail($job['to'],'Order upload activity needs review',$job['body'],['Content-Type: text/plain; charset=UTF-8']); } catch (\Throwable $e) { $ok=false; }
                if (!self::lock()) { update_option('pdou_alert_failed',time(),false); return; }
                $jobs=get_option('pdou_alert_jobs',[]); if (!is_array($jobs)) { $jobs=[]; }
                // An older sender must not erase a newer reservation after an unusually slow SMTP call.
                if (($jobs[$uid]['attempts']??0)===$job['attempts'] && ($ok || $job['attempts']>=3)) { unset($jobs[$uid]); }
                if (!$ok) { update_option('pdou_alert_failed',time(),false); }
                update_option('pdou_alert_jobs',$jobs,false);
                if (++$processed>=5 || microtime(true)-$start>=5) { break; }
            }
            update_option('pdou_alert_jobs',$jobs,false);
            update_option('pdou_alert_queue_status',['pending'=>count($jobs),'checked_at'=>time()],false);
            if ($jobs) { self::schedule(max(time()+30,min(array_column($jobs,'due')))); }
        } finally { self::unlock(); }
    }
}
