<?php
namespace PureDistilling\OrderUpload;
final class ReviewStore {
    private static function pending_key(): string { return 'pdou_p_'.get_current_user_id(); }
    private static function record_key(string $token): string {
        $pending=get_option(self::pending_key(),[]);
        return is_array($pending) && isset($pending['token']) && hash_equals($pending['token'],$token) ? self::pending_key() : self::key();
    }
    private static function key(): string {
        return 'pdou_r_' . hash('sha256', get_current_user_id() . '|' . wp_get_session_token() . '|' . WC()->session->get_customer_id());
    }
    public static function create(array $rows): string {
        $pending=get_option(self::pending_key(),[]);
        if (($pending['state']??'')==='processing') { throw new UploadException('A previous order needs a cart check. Reopen Upload Order to recover it before uploading again.'); }
        if ($pending) { self::delete_matching(self::pending_key(),$pending); }
        $old = get_option(self::key(), []);
        if (($old['state'] ?? '') === 'processing') { throw new UploadException('A previous upload confirmation was interrupted. Check your cart before trying again.'); }
        $token = bin2hex(random_bytes(32));
        $record=['token'=>$token,'expires'=>time()+1800,'state'=>'review','rows'=>$rows,'version'=>1,'revisions'=>0];
        if (strlen(maybe_serialize($record))>393216) { throw new UploadException('This review contains too much text. Use the template with shorter SKU values.'); }
        if (!update_option(self::key(), $record, false)) { throw new UploadException('The review could not be saved. Try again later.'); }
        return $token;
    }
    public static function get(string $token): array {
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) { throw new UploadException('Upload your file again to start a new review.'); }
        $key=self::record_key($token);$r = get_option($key, []);
        if ($r && ($r['expires'] ?? 0) <= time() && ($r['state']??'')!=='processing') { self::delete_matching($key, $r); $r = []; }
        if (!$r || !hash_equals($r['token'] ?? '', $token)) { throw new UploadException('This review has expired or was replaced. Upload your file again.'); }
        return $r;
    }
    public static function active(): ?array {
        $pending=get_option(self::pending_key(),[]);
        if (is_array($pending) && ($pending['state']??'')==='processing') { return $pending; }
        $r = get_option(self::key(), []);
        if (!is_array($r) || !isset($r['token']) || (($r['expires'] ?? 0) <= time() && ($r['state']??'')!=='processing')) { return null; }
        return $r;
    }
    public static function begin(string $token, array $selected): void {
        $r = self::get($token);
        if ($r['state'] !== 'review') { throw new UploadException('This confirmation has already started.'); }
        $old = $r; $r['state'] = 'processing';
        $r['origin_key']=self::key();
        $r['progress'] = ['selected'=>$selected, 'cursor'=>0, 'items'=>[], 'batch'=>[], 'needs_check'=>false];
        if (strlen(maybe_serialize($r))>1048576) { throw new UploadException('This review is too large to confirm safely. Start a smaller upload.'); }
        // One durable processing record per account survives login/review expiry.
        // Write it BEFORE mutation, then remove the original session review.
        $pending=get_option(self::pending_key(),[]);
        if (($pending['state']??'')==='processing') { throw new UploadException('Another order needs checking before confirmation.'); }
        if (!update_option(self::pending_key(),$r,false)) { throw new UploadException('Confirmation progress could not be saved.'); }
        self::retire_origin($r);
    }
    public static function retire_origin(array $r): void {
        $key=$r['origin_key']??null;
        if (!is_string($key) || !preg_match('/^pdou_r_[a-f0-9]{64}$/D',$key)) { return; }
        $original=get_option($key,[]);
        if (is_array($original) && ($original['token']??null)===$r['token']) {
            self::delete_matching($key,$original);
            if (get_option($key,[])===$original) { throw new UploadException('The original review could not be retired. Check your cart before continuing.'); }
        }
    }
    public static function progress(string $token, array $progress): void {
        $r = self::get($token);
        if ($r['state'] !== 'processing') { throw new UploadException('This confirmation is no longer running.'); }
        $old = $r; $r['progress'] = $progress; self::transition($old, $r);
    }
    public static function update(string $token, array $rows, bool $substantive = false): void {
        $r = self::get($token);
        if ($r['state'] !== 'review') { throw new UploadException('This review has already been confirmed. Check your cart.'); }
        $old = $r; $r['rows'] = $rows; ++$r['version'];
        if ($substantive) { $r['revisions']=($r['revisions']??0)+1; }
        self::transition($old, $r);
    }
    public static function claim(string $token): bool {
        $r = self::get($token);
        if ($r['state'] !== 'review') { return false; }
        $old = $r; $r['state'] = 'processing'; self::transition($old, $r); return true;
    }
    public static function finish(string $token, array $result): void {
        $r = self::get($token); self::retire_origin($r); $old = $r; $r['state'] = 'done'; $r['result'] = $result; $r['expires']=time()+1800; self::transition($old, $r);
    }
    private static function transition(array $old, array $new): void {
        global $wpdb;
        if (strlen(maybe_serialize($new))>1048576) { throw new UploadException('The review is too large to save safely. Check your cart before retrying.'); }
        $key=self::record_key($old['token']);
        $changed = $wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s", maybe_serialize($new), $key, maybe_serialize($old)));
        if ($changed !== 1) { throw new UploadException('The review state could not be saved. If you were confirming, check your cart before trying again.'); }
        self::clear_cache($key);
    }
    private static function clear_cache(string $key): void {
        wp_cache_delete($key, 'options'); wp_cache_delete('notoptions', 'options');
    }
    private static function delete_matching(string $key, array $value): void {
        global $wpdb;
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $key, maybe_serialize($value)));
        self::clear_cache($key);
    }
    /** INSERT IGNORE is a true unique insert; add_option uses an upsert and is not a lock. */
    public static function lock(): array {
        // The connection-owned account lock already covers all review writers.
        // Its lifetime ends with the worker, so a killed request leaves no lease delay.
        if (class_exists(CartGuard::class) && CartGuard::active()) { return []; }
        $key = 'pdou_l_' . get_current_user_id();
        $old = get_option($key, []);
        if (is_array($old) && ($old['expires'] ?? PHP_INT_MAX) < time()) { self::delete_matching($key, $old); }
        $value = ['owner' => bin2hex(random_bytes(16)), 'expires' => time() + 300];
        global $wpdb;
        $inserted = $wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $key, maybe_serialize($value)));
        if ($inserted !== 1) { throw new UploadException('Another upload request is running. Wait a moment and check your cart before retrying.'); }
        self::clear_cache($key); return [$key, $value];
    }
    public static function unlock(array $lock): void {
        if (!$lock) { return; }
        self::delete_matching($lock[0], $lock[1]);
    }
    public static function revision_budget(array $review, int $changed): void {
        if ($changed<1) { return; }
        if (($review['revisions']??0)>=10) { throw new UploadException('Please start a new review or use the order form.', 'throttled'); }
        $key='pdou_a_'.get_current_user_id().'_edits';$now=time();$state=get_option($key,['events'=>[]]);
        if (!is_array($state) || !is_array($state['events']??null)) { throw new UploadException('Review checks are temporarily unavailable.'); }
        foreach ($state['events'] as $event) { if (!is_array($event) || !is_int($event['at']??null) || !is_int($event['rows']??null) || $event['rows']<1 || $event['rows']>500) { throw new UploadException('Review checks are temporarily unavailable.'); } }
        $events=array_values(array_filter($state['events'],static fn($e)=>$e['at']>$now-3600));
        $total=array_sum(array_column($events,'rows'));
        if ($total+$changed>5000 || count($events)>=300) { throw new UploadException('Please try updating your order later.', 'throttled'); }
        $events[]=['at'=>$now,'rows'=>$changed];
        if (!update_option($key,['events'=>$events,'expires'=>$now+3600],false)) { throw new UploadException('Review checks could not be saved.'); }
    }
    /** Called while holding the account lock. */
    public static function rate_limit(string $budget = 'upload'): void {
        $uid = get_current_user_id(); $now = time();
        if ($budget === 'request') {
            $key = 'pdou_a_' . $uid . '_requests'; $r = get_option($key, []);
            if (($r['expires'] ?? 0) <= $now) { $r = ['count'=>0, 'expires'=>$now+60]; }
            if ($r['count'] >= 30) { throw new UploadException('Too many order upload requests. Please wait one minute before trying again.', 'throttled'); }
            ++$r['count'];
        } else {
            $key = 'pdou_a_' . $uid . '_upload_v2'; $r = get_option($key, ['attempts'=>[]]);
            if (!is_array($r) || !is_array($r['attempts'] ?? null)) { throw new UploadException('Upload checks are temporarily unavailable. Try again later.'); }
            $times = [];
            foreach ($r['attempts'] as $t) {
                if (!is_int($t)) { throw new UploadException('Upload checks are temporarily unavailable. Try again later.'); }
                if ($t > $now - 86400) { $times[] = $t; }
            }
            if (count($times) >= 20) { throw new UploadException('Please try uploading again later, or use the order form.', 'throttled'); }
            if (count(array_filter($times, static fn($t) => $t > $now - 60)) >= 5) { throw new UploadException('Please wait before uploading another file.', 'throttled'); }
            $times[] = $now; $r = ['attempts'=>$times, 'expires'=>$now+86400];
        }
        if (!update_option($key, $r, false)) { throw new UploadException('Upload checks are temporarily unavailable. Try again later.'); }
    }
    public static function cleanup(): void {
        global $wpdb;
        $started=microtime(true);$cursors=get_option("pdou_cleanup_cursors",[]);
        if (!is_array($cursors)) { $cursors=[]; }
        $catchup=false;$visited=0;$deleted_count=0;
        foreach (["pdou_r_","pdou_p_","pdou_l_","pdou_a_"] as $prefix) {
            for ($round=0;$round<100;$round++) {
                if (microtime(true)-$started>=5) { $catchup=true;break 2; }
                $items=$wpdb->get_results($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND option_name > %s ORDER BY option_name ASC LIMIT 50",$wpdb->esc_like($prefix)."%",(string)($cursors[$prefix]??""))) ?: [];
                foreach ($items as $item) {
                    // Fetch one bounded record at a time; old reviews may be large.
                    $raw=$wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",$item->option_name));
                    if (!is_string($raw)) { continue; }
                    $v=maybe_unserialize($raw);++$visited;
                    if (is_array($v) && ($v["expires"]??PHP_INT_MAX)<time() && ($v['state']??'')!=='processing') {
                        $deleted=$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",$item->option_name,$raw));
                        if ($deleted) { ++$deleted_count;wp_cache_delete($item->option_name,"options"); }
                    }
                    $cursors[$prefix]=$item->option_name;
                    if (microtime(true)-$started>=5) { $catchup=true;break 3; }
                }
                if (count($items)<50) { $cursors[$prefix]="";break; }
                if ($round===99) { $catchup=true; }
            }
        }
        update_option("pdou_cleanup_cursors",$cursors,false);
        update_option("pdou_cleanup_status",["at"=>time(),"visited"=>$visited,"deleted"=>$deleted_count,"catchup"=>$catchup],false);
        if ($catchup && function_exists("wp_next_scheduled") && !wp_next_scheduled("pdou_cleanup_catchup")) { wp_schedule_single_event(time()+60,"pdou_cleanup_catchup"); }
    }
}
