<?php
namespace PureDistilling\OrderUpload;
/** Private metadata and order rows only: no original files, credentials or session tokens. */
require_once __DIR__ . '/class-alert-queue.php';
final class AuditLog {
    public const ROW_BYTES = 65536;
    public const DAILY_BYTES = 2097152;
    public const EVENTS = ['reviewed', 'revised', 'confirmed', 'rejected', 'suspicious', 'throttled', 'error'];
    public static function register(): void {
        add_action('admin_init', [self::class, 'maybe_install'], 5);
        AlertQueue::register();
        add_action('pdou_cleanup', [self::class, 'cleanup']);
        add_action('pdou_log_cleanup_catchup', [self::class, 'cleanup']);
    }
    public static function table(): string { global $wpdb; return $wpdb->prefix . 'pdou_log'; }
    public static function maybe_install(): void {
        if (get_option('pdou_log_schema') === '1' || (int)get_option('pdou_log_install_retry',0) > time()) { return; }
        update_option('pdou_log_install_retry',time()+3600,false);
        try { self::install(); } catch (\Throwable $e) { self::failed('pdou_log_failed'); }
    }
    private static function install(): void {
        if (get_option('pdou_log_schema') === '1') { return; }
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $charset = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            created_at bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            event varchar(20) NOT NULL,
            upload_ref varchar(64) NOT NULL DEFAULT '',
            file_name varchar(240) NOT NULL DEFAULT '',
            file_size bigint(20) unsigned NOT NULL DEFAULT 0,
            file_hash varchar(64) NOT NULL DEFAULT '',
            reason text NOT NULL,
            rows_json longtext NOT NULL,
            PRIMARY KEY  (id),
            KEY created_at (created_at),
            KEY user_id (user_id),
            KEY upload_ref (upload_ref)
        ) $charset;");
        $columns = $wpdb->get_col('SHOW COLUMNS FROM ' . $table);
        $required = ['id','created_at','user_id','event','upload_ref','file_name','file_size','file_hash','reason','rows_json'];
        if (is_array($columns) && !array_diff($required, $columns)) { update_option('pdou_log_schema', '1', false); delete_option('pdou_log_install_retry'); }
        else { self::failed('pdou_log_failed'); }
    }
    public static function settings(): array {
        $r = get_option('pdou_log_settings', []);
        return self::validate_settings(is_array($r) ? $r : []);
    }
    public static function validate_settings(array $r): array {
        $email = is_string($r['email'] ?? null) ? trim($r['email']) : '';
        if (strlen($email) > 254 || strpbrk($email, "\r\n") !== false || !is_email($email)) { $email = ''; }
        return ['retention_days' => max(7, min(365, (int) ($r['retention_days'] ?? 90))), 'email' => $email, 'alerts' => !empty($r['alerts']) && $email !== '', 'delete_on_uninstall'=>!empty($r['delete_on_uninstall'])];
    }
    public static function text($v, int $max = 600): string {
        $s = is_scalar($v) ? wp_check_invalid_utf8((string) $v) : '';
        $s = preg_replace('/[\x00-\x1F\x7F]/', ' ', $s);
        $s = substr($s, 0, $max);
        while ($s !== '' && !preg_match('//u', $s)) { $s = substr($s, 0, -1); }
        return $s;
    }
    public static function file_info($file): array {
        if (!is_array($file)) { return []; }
        $name = is_string($file['name'] ?? null) ? sanitize_file_name(basename(str_replace('\\', '/', $file['name']))) : '';
        $info = ['name' => self::text($name, 240), 'size' => 0, 'hash' => ''];
        $path = $file['tmp_name'] ?? null;
        if (is_string($path) && is_uploaded_file($path)) {
            $info['size'] = (int) filesize($path);
            if ($info['size'] > 0 && $info['size'] <= Parser::MAX_BYTES) { $info['hash'] = hash_file('sha256', $path) ?: ''; }
        }
        return $info;
    }
    public static function rows(array $rows): array {
        $out = [];
        foreach (array_slice($rows, 0, 500) as $r) {
            if (!is_array($r)) { continue; }
            $row = [];
            foreach (['sku', 'name', 'quantity', 'requested', 'accepted', 'added', 'status', 'reason'] as $field) { if (isset($r[$field])) { $row[$field] = self::text($r[$field], $field === 'sku' ? 512 : 600); } }
            if (isset($r['rows']) && is_array($r['rows'])) { $row['rows'] = array_map('intval', array_slice($r['rows'], 0, 500)); }
            $out[] = $row;
        }
        return $out;
    }
    /** Hash covers the allowlisted snapshot; the envelope makes omissions visible. */
    public static function payload(array $rows, bool $metadata_only = false): string {
        $safe = self::rows($rows); $fields_truncated=0; $coordinates_omitted=0;
        foreach (array_slice($rows,0,500) as $row) {
            if (!is_array($row)) { continue; }
            foreach (['sku','name','quantity','requested','accepted','added','status','reason'] as $field) {
                if (isset($row[$field]) && is_scalar($row[$field]) && strlen((string)$row[$field])>($field==='sku' ? 512 : 600)) { ++$fields_truncated; }
            }
            if (isset($row['rows']) && is_array($row['rows'])) { $coordinates_omitted+=max(0,count($row['rows'])-500); }
        }
        $outcomes=[]; $totals=['requested'=>0,'accepted'=>0,'added'=>0];
        foreach ($safe as $row) {
            $status=$row['status']??'other';
            if (!in_array($status,['added','uncertain','ready','invalid','unavailable','out','insufficient','rejected','excluded'],true)) { $status='other'; }
            $outcomes[$status]=($outcomes[$status]??0)+1;
            foreach ($totals as $field=>$sum) {
                $value=$row[$field]??($field==='requested' ? ($row['quantity']??'') : '');
                if (ctype_digit((string)$value)) { $totals[$field]+=min(1000000000,(int)$value); }
            }
        }
        $full = wp_json_encode($safe, JSON_UNESCAPED_UNICODE);
        $data = ['outcomes'=>$outcomes,'totals'=>$totals,'rows'=>[], 'total_rows'=>count($rows), 'stored_rows'=>0, 'omitted_rows'=>count($rows),
            'truncated'=>count($rows)>0, 'fields_truncated'=>$fields_truncated, 'source_rows_omitted'=>$coordinates_omitted, 'hash_scope'=>'bounded_allowlisted_rows', 'sha256'=>hash('sha256', $full ?: '[]'), 'budget_exhausted'=>$metadata_only];
        if (!$metadata_only) {
            $bytes = strlen(wp_json_encode($data, JSON_UNESCAPED_UNICODE));
            foreach ($safe as $row) {
                $size = strlen(wp_json_encode($row, JSON_UNESCAPED_UNICODE)) + 1;
                if ($bytes + $size > self::ROW_BYTES - 64) { break; }
                $data['rows'][] = $row; $bytes += $size;
            }
        }
        $data['stored_rows'] = count($data['rows']);
        $data['omitted_rows'] = $data['total_rows'] - $data['stored_rows'];
        $data['truncated'] = $data['omitted_rows'] > 0 || $fields_truncated>0 || $coordinates_omitted>0;
        return wp_json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    public static function revision(array $file, array $before, array $after, string $reason, string $ref = ''): void {
        $delta = [];
        foreach ($after as $i=>$row) { if (($before[$i] ?? null) !== $row) { $delta[] = $row; } }
        self::record('revised', $file, $delta, $reason, $ref);
    }
    /** Logging/email errors must not change the cart or interrupt the customer response. */
    public static function record(string $event, array $file, array $rows, string $reason, string $ref = ''): void {
        try { self::write($event, $file, $rows, $reason, $ref); }
        catch (\Throwable $e) { self::failed('pdou_log_failed'); }
    }
    private static function write(string $event, array $file, array $rows, string $reason, string $ref): void {
        $uid = get_current_user_id();
        if ($uid < 1 || !in_array($event, self::EVENTS, true)) { return; }
        global $wpdb;
        $key = 'pdou_a_' . $uid . '_audit'; $state = get_option($key, []); $now = time();
        if (!is_array($state)) { $state = []; }
        $failure = in_array($event, ['rejected', 'suspicious', 'throttled'], true);
$times = is_array($state['failure_times'] ?? null) ? $state['failure_times'] : [];
        $times = array_values(array_filter($times, static fn($t) => is_int($t) && $t > $now - 600));
        if ($failure) { $times[] = $now; }
        $state['failure_times'] = array_slice($times, -300);
        $state['failures'] = count($state['failure_times']);
        // Hour buckets deliberately retain the whole oldest hour: never undercount a rolling day.
        $buckets = is_array($state['detail_buckets'] ?? null) ? $state['detail_buckets'] : [];
        foreach ($buckets as $hour=>$bytes) { if ((int)$hour < intdiv($now-86400,3600)) { unset($buckets[$hour]); } }
        $used = array_sum($buckets); $payload = self::payload($rows);
        $exhausted = $used + strlen($payload) > self::DAILY_BYTES;
        if ($exhausted) { $payload = self::payload($rows, true); }
        $essential = in_array($event, ['confirmed','error'], true);
        $coalesced = $exhausted && !$essential && ($state['metadata_until'][$event] ?? 0) > $now;
        if ($coalesced) {
            $state['coalesced'][$event] = (int)($state['coalesced'][$event] ?? 0) + 1;
            $state['last_coalesced_hash'] = hash('sha256', self::payload($rows, true));
            $summary=json_decode($payload,true); $summary['coalesced_events']=$state['coalesced'][$event]; $summary['last_seen']=$now;
            // Keep aggregate evidence for the log retention period, beyond the budget option's lifetime.
            if ($wpdb->update(self::table(),['rows_json'=>wp_json_encode($summary,JSON_UNESCAPED_UNICODE)],
                ['id'=>(int)($state['metadata_entry'][$event]??0),'user_id'=>$uid],['%s'],['%d','%d'])===false) { self::failed('pdou_log_failed'); }
        }
        $skip = $coalesced || $event === 'throttled'  && ($state['throttled_until'] ?? 0) > $now;
        if (!$skip) {
            $data = ['created_at' => $now, 'user_id' => $uid, 'event' => $event, 'upload_ref' => preg_match('/^[a-f0-9]{64}$/D', $ref) ? $ref : '',
                'file_name' => self::text($file['name'] ?? '', 240), 'file_size' => max(0, (int) ($file['size'] ?? 0)), 'file_hash' => preg_match('/^[a-f0-9]{64}$/D', $file['hash'] ?? '') ? $file['hash'] : '',
                'reason' => self::text($reason), 'rows_json' => $payload];
            if ($wpdb->insert(self::table(), $data, ['%d','%d','%s','%s','%s','%d','%s','%s','%s']) !== 1) { update_option('pdou_log_failed', $now, false); return; }
            $state['entry_id'] = (int) $wpdb->insert_id;
            if (!$exhausted) { $hour = intdiv($now,3600); $buckets[$hour] = ($buckets[$hour] ?? 0) + strlen($payload); }
            else { $state['metadata_until'][$event] = $now + 600; $state['metadata_entry'][$event]=(int)$wpdb->insert_id; $state['coalesced'][$event]=0; }
            if ($event === 'throttled') { $state['throttled_until'] = $now + 120; }
        }
        $state['detail_buckets'] = $buckets; $state['detail_bytes'] = array_sum($buckets);
        $cfg = self::settings(); $alert = $event === 'suspicious' || ($failure && $state['failures'] >= 3);
        $send = $alert && $cfg['alerts'] && ($state['alert_until'] ?? 0) <= $now;
        if ($send) { $state['alert_until'] = $now + 600; }
        $state['expires'] = $now + 90000;
        // Reserve the alert before mail to avoid duplicate sends. Called under the account lock.
        if (!update_option($key, $state, false) && get_option($key) !== $state) { return; }
        if ($send) {
            $user = get_userdata($uid);
            $url = add_query_arg(['page' => 'pdou-upload-log', 'entry' => (int) ($state['entry_id'] ?? 0)], admin_url('admin.php'));
            $body = "An order upload needs review. A rejection is not proof of an attack.\n\nAccount: " . self::text($user->user_login ?? '', 100) . " (ID $uid)\nTime (UTC): " . gmdate('Y-m-d H:i:s', $now) . "\nEvent: $event\nFilename: " . self::text($file['name'] ?? '', 240) . "\nReason: " . self::text($reason) . "\nFailed attempts in this window: " . $state['failures'] . "\n\nAdmin log: $url\n\nRepeat alerts for this account are grouped for ten minutes. No uploaded file is attached.";
            AlertQueue::enqueue($uid, $cfg['email'], $body);
        }
    }
    private static function failed(string $key): void { try { update_option($key, time(), false); } catch (\Throwable $e) { /* Ordering must continue even if failure reporting is unavailable. */ } }
    public static function cleanup(): void {
        try {
            global $wpdb; $start=microtime(true); $deleted=0;
            $cutoff=time()-self::settings()['retention_days']*86400;
            do {
                $n=$wpdb->query($wpdb->prepare('DELETE FROM '.self::table().' WHERE created_at < %d LIMIT 50',$cutoff));
                if ($n===false) { self::failed('pdou_log_failed'); return; }
                $deleted+=(int)$n;
            } while ($n===50 && microtime(true)-$start<5);
            $oldest=(int)$wpdb->get_var($wpdb->prepare('SELECT MIN(created_at) FROM '.self::table().' WHERE created_at < %d',$cutoff));
            update_option('pdou_log_cleanup_status',['checked_at'=>time(),'deleted'=>$deleted,'oldest_expired'=>$oldest],false);
            if ($oldest && !wp_next_scheduled('pdou_log_cleanup_catchup')) {
                wp_schedule_single_event(time()+60,'pdou_log_cleanup_catchup');
            }
        } catch (\Throwable $e) { self::failed('pdou_log_failed'); }
    }
}
