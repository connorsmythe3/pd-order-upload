<?php
namespace PureDistilling\OrderUpload;
require_once __DIR__ . '/class-confirmation.php';
final class Controller {
    private static array $audit_partial = [];
    public static function register(): void {
        foreach (['bootstrap', 'upload', 'revise', 'confirm', 'advance', 'recover', 'report'] as $action) {
            add_action('wp_ajax_pdou_' . $action, static function() use ($action) { self::dispatch($action); });
        }
    }
    public static function dispatch(string $action): void {
        self::$audit_partial = [];
        $lock = null; $reply = null; $error = null; $audit_allowed = false; $audit_file = []; $audit_ref = ''; $audit_category = 'rejected'; $audit_before=[];
        try {
            Access::assert_request($action === 'bootstrap');
            $audit_allowed = true;
            if ($action === 'upload' && class_exists(AuditLog::class)) { $audit_file = AuditLog::file_info($_FILES['order_file'] ?? null); }
            nocache_headers(); header('X-Content-Type-Options: nosniff');
            if ($action === 'bootstrap') {
                $reply = ['nonce' => wp_create_nonce('pd_order_upload'), 'cart_url' => wc_get_cart_url(), 'currency' => get_woocommerce_currency(), 'captcha' => class_exists(Captcha::class) ? Captcha::public_config() : ['enabled'=>false]];
                $active=ReviewStore::active();
                if ($active && $active['state']==='processing') { $reply['resume']=['token'=>$active['token'],'version'=>$active['version'],'progress'=>Confirmation::status($active)]; }
            } else {
                $lock = ReviewStore::lock();
                if (class_exists(CartGuard::class)) { CartGuard::assert_owned(); }
                ReviewStore::rate_limit('request');
                if ($action === 'upload') {
                    ReviewStore::rate_limit();
                    if (class_exists(Captcha::class)) { Captcha::verify($_POST['captcha_token'] ?? null); }
                    $file = $_FILES['order_file'] ?? null;
                    if (!is_array($file) || !isset($file['error'], $file['tmp_name'], $file['name']) || $file['error'] !== UPLOAD_ERR_OK || !is_string($file['tmp_name']) || !is_string($file['name']) || !is_uploaded_file($file['tmp_name'])) {
                        throw new UploadException('Upload a CSV or Excel .xlsx file up to 250 KB.');
                    }
                    try { $rows = Parser::combine(Parser::parse($file['tmp_name'], strtolower(pathinfo($file['name'], PATHINFO_EXTENSION)))); }
                    finally { unlink($file['tmp_name']); }
                    $token = ReviewStore::create(Validator::review($rows));
                    $audit_ref = hash('sha256', $token);
                    $reply = ['review' => self::public_review($token, ReviewStore::get($token))];
                } else {
                    $token = self::string_input('token', 64);
                    $audit_ref = hash('sha256', $token);
                    if ($action === 'report') { $reply = ['report' => self::report_csv($token)]; }
                    elseif ($action === 'recover') { $reply=['results'=>Confirmation::recover($token,self::string_input('acknowledged',20)==='checked')]; }
                    else {
                        $version = self::string_input('version', 10);
                        if (!ctype_digit($version)) { throw new UploadException('Refresh the review and try again.'); }
                        if ($action==='advance') { $reply=['results'=>Confirmation::advance($token,(int)$version)]; }
                        else {
                        $payload = self::string_input('data', 524288);
                        try { $data = json_decode($payload, true, 10, JSON_THROW_ON_ERROR); }
                        catch (\JsonException $e) { throw new UploadException('Invalid order selection.'); }
                        if (!is_array($data) || count($data) > Parser::MAX_ROWS) { throw new UploadException('Invalid order selection.'); }
                        if ($action==='revise') { $audit_before=ReviewStore::get($token)['rows']; }
                        $reply = $action === 'revise'
                            ? ['review' => self::public_review($token, self::revise_review($token, (int) $version, $data))]
                            : ['results' => self::confirm_review($token, (int) $version, $data)];
                        }
                    }
                }
            }
        } catch (UploadException $e) { $error = $e->getMessage(); $audit_category = in_array($e->category, ['suspicious', 'throttled'], true) ? $e->category : 'rejected'; }
        catch (\Throwable $e) { $audit_category = 'error'; $error = 'The request could not be completed. If you were adding items, check your cart before trying again.'; }
        finally {
            self::$audit_partial=class_exists(Confirmation::class)?Confirmation::partial():self::$audit_partial;
            if ($audit_allowed && $lock !== null && class_exists(AuditLog::class) && in_array($action, ['upload', 'revise', 'confirm', 'advance', 'recover'], true)) {
                $pending=!empty($reply['results']['progress']);
                $event = $error !== null ? $audit_category : ['upload'=>'reviewed', 'revise'=>'revised', 'confirm'=>'confirmed','advance'=>'confirmed','recover'=>'confirmed'][$action];
                if ($pending && !empty($reply['results']['progress']['needs_check'])) { $event='error'; }
                $reason = $error ?? ($pending ? ($reply['results']['progress']['needs_check'] ? 'Confirmation interrupted; saved cart state is uncertain and reconciliation is required.' : 'Confirmation batch committed; more rows remain.') : (in_array($action,['confirm','advance','recover'],true) ? 'Confirmation response recorded. Replays do not add items again.' : 'Order rows checked against current products and stock.'));
                if ($error !== null && self::$audit_partial) { $reason .= ' Recorded rows show observed cart additions before the failure; saved cart state may be uncertain.'; }
                if ($action==='revise' && !$error && is_callable([AuditLog::class,'revision'])) { AuditLog::revision($audit_file,$audit_before,$reply['review']['rows'],$reason,$audit_ref); }
                else { AuditLog::record($event, $audit_file, $reply['review']['rows'] ?? $reply['results']['items'] ?? self::$audit_partial, $reason, $audit_ref); }
            }
            if ($lock) { ReviewStore::unlock($lock); }
        }
        // wp_send_json exits: release the lock before responding.
        if ($error !== null) { wp_send_json_error(['message' => $error], 400); }
        else { wp_send_json_success($reply); }
    }
    private static function string_input(string $key, int $max): string {
        $v = $_POST[$key] ?? null;
        if (!is_string($v) || strlen($v) > $max) { throw new UploadException('Invalid request. Refresh the page and try again.'); }
        return wp_unslash($v);
    }
    public static function public_review(string $token, array $r): array {
        $rows = [];
        foreach ($r['rows'] as $row) {
            $safe = $row; unset($safe['product_id']); $rows[] = $safe;
        }
        return ['token' => $token, 'version' => $r['version'], 'rows' => $rows, 'currency' => get_woocommerce_currency()];
    }
    /** Caller holds the per-account lock. All edits are revalidated on the server. */
    public static function revise_review(string $token, int $version, array $edits): array {
        $r = ReviewStore::get($token);
        if ($r['state'] !== 'review' || $r['version'] !== $version) { throw new UploadException('The review changed. Upload your file again if another tab is open.'); }
        if (count($edits) !== count($r['rows'])) { throw new UploadException('Send the complete review for revalidation.'); }
        $source = []; foreach ($r['rows'] as $row) { $source[$row['id']] = $row; }
        $rows = []; $selected = []; $seen = []; $changed=0; $selection_only=[];
        foreach ($edits as $edit) {
            if (!is_array($edit) || !isset($edit['id'], $edit['sku'], $edit['quantity'], $edit['selected']) || !is_string($edit['id']) || !isset($source[$edit['id']]) || isset($seen[$edit['id']]) || !is_string($edit['sku']) || !is_string($edit['quantity']) || !is_bool($edit['selected'])) { throw new UploadException('Invalid review edits.'); }
            $seen[$edit['id']] = true; $old = $source[$edit['id']];
            $sku = trim($edit['sku']); $q = trim($edit['quantity']);
            if ($sku !== $old['sku'] || $q !== (string)($old['accepted']>0?$old['accepted']:$old['quantity'])) { ++$changed; }
            $copy=$old;$copy['selected']=$old['eligible']&&$edit['selected'];$selection_only[]=$copy;
            if (strlen($sku) > 512 || strlen($q) > 32 || !preg_match('//u', $sku) || preg_match('/[\x00-\x1F]/', $sku)) { throw new UploadException('SKU or quantity contains unsupported text.'); }
            $error = $sku === '' ? 'Enter a SKU.' : null;
            if (preg_match('/^[+-]?[0-9]+(?:\.[0-9]+)?[eE][+-]?[0-9]+$/D', $sku)) { $error = 'Scientific notation detected. Enter the complete SKU as text.'; }
            if (Parser::quantity($q) === null) { $error = 'Quantity must be a positive whole number, up to 1,000,000.'; }
            $rows[] = ['row' => $old['row'], 'rows' => $old['rows'], 'sku' => $sku, 'quantity' => $q, 'error' => $error, 'original_quantity' => $old['original_quantity'] ?? $old['requested']];
            $selected['sku:' . $sku] = ($selected['sku:' . $sku] ?? false) || $edit['selected'];
        }
        ReviewStore::revision_budget($r,$changed);
        if (!$changed) { ReviewStore::update($token,$selection_only); return ReviewStore::get($token); }
        $combined=Parser::combine($rows);
        // Reuse unchanged identities, but recheck live stock/policy; no repeated SKU queries.
        $known=[];foreach($r['rows'] as $old){if(($old['product_id']??0)>0){$known['sku:'.$old['sku']]=$old['product_id'];}}
        $rows = Validator::review($combined,$known);
        foreach ($rows as &$row) { $row['selected'] = $row['eligible'] && ($selected['sku:' . $row['sku']] ?? false); }
        unset($row);
        ReviewStore::update($token, $rows, true); return ReviewStore::get($token);
    }
    /** Caller holds the account lock; confirmation progress is durable. */
    public static function confirm_review(string $token, int $version, array $selected): array {
        return Confirmation::start($token, $version, $selected);
    }
    private static function notice_reason(int $offset): string {
        $notices = array_slice(wc_get_notices('error'), $offset);
        $message = isset($notices[0]['notice']) ? wp_strip_all_tags($notices[0]['notice']) : '';
        return $message !== '' ? wp_html_excerpt($message, 500, '') : 'This quantity did not pass the store’s ordering rules. Adjust it or use the normal order form.';
    }
    public static function report_csv(string $token): string {
        $r = ReviewStore::get($token); $handle = fopen('php://temp', 'w+');
        fputcsv($handle, ['Source rows', 'SKU', 'Requested', 'Accepted', 'Added', 'Status', 'Reason'], ',', '"', '');
        $rows = $r['state'] === 'done' ? $r['result']['items'] : $r['rows'];
        foreach ($rows as $row) {
            if ($r['state'] !== 'done' && $row['eligible']) { continue; }
            $fields = [implode(', ', $row['rows']), $row['sku'], $row['requested'], $row['accepted'], $row['added'] ?? '', $row['status'], $row['reason']];
            $fields = array_map(static function($v) {
                $v = (string) $v;
                if (preg_match('/^[\s\x00-\x1F]*[=+\-@]/u', $v) || preg_match('/^0[0-9]+$/D', $v)) { $v = "'" . $v; }
                return $v;
            }, $fields);
            fputcsv($handle, $fields, ',', '"', '');
        }
        rewind($handle); $csv = stream_get_contents($handle); fclose($handle); return $csv;
    }
}
