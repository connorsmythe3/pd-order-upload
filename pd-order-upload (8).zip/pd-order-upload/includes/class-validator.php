<?php
namespace PureDistilling\OrderUpload;
final class Validator {
    private static bool $cache_enabled = false;
    private static ?array $quantity_cache = null;
    public static function use_cart_cache(bool $enabled): void { self::$cache_enabled=$enabled; self::$quantity_cache=null; }
    public static function invalidate_cart_cache(): void { self::$quantity_cache=null; }
    private static function quantities(): array {
        if (self::$cache_enabled && self::$quantity_cache !== null) { return self::$quantity_cache; }
        $map=['items'=>[],'managed'=>[]];
        foreach (WC()->cart->get_cart() as $item) {
            $id=(int)$item['data']->get_id();$managed=(int)$item['data']->get_stock_managed_by_id();$q=(float)$item['quantity'];
            $map['items'][$id]=($map['items'][$id]??0)+$q;$map['managed'][$managed]=($map['managed'][$managed]??0)+$q;
        }
        if (self::$cache_enabled) { self::$quantity_cache=$map; }
        return $map;
    }
    public static function item_cart_quantity(int $product_id): float {
        return (float)(self::quantities()['items'][$product_id]??0);
    }
    public static function cart_quantity(int $managed_id): float {
        return (float)(self::quantities()['managed'][$managed_id]??0);
    }
    public static function check(int $product_id, int $addition): array {
        $bad = ['eligible' => false, 'available' => 0, 'status' => 'unavailable', 'reason' => 'This item is not available to your account.'];
        $p = wc_get_product($product_id);
        if (!$p || !$p->is_type('simple') || $p->get_status() !== 'publish' || !$p->is_visible() || !$p->is_purchasable() || !Access::roles()) { return $bad; }
        $restricted = get_post_meta($product_id, 'wwpp_product_wholesale_visibility_filter', false);
        $restricted = array_values(array_filter($restricted, 'is_string'));
        if ($restricted && !in_array('all', $restricted, true) && !array_intersect($restricted, Access::roles())) { return $bad; }
        if (defined('WWPP_OPTION_PRODUCT_CAT_WHOLESALE_ROLE_FILTER')) {
            $categories = get_option(WWPP_OPTION_PRODUCT_CAT_WHOLESALE_ROLE_FILTER, []);
            foreach ($p->get_category_ids() as $id) {
                $required = (array) ($categories[$id] ?? []);
                if ($required && !in_array('all', $required, true) && !array_intersect($required, Access::roles())) { return $bad; }
            }
        }
        // WooCommerce considers onbackorder in stock; uploads never create backorders.
        if (!$p->is_in_stock() || (method_exists($p, 'get_stock_status') && $p->get_stock_status() === 'onbackorder')) { return ['eligible' => false, 'available' => 0, 'status' => 'out', 'reason' => 'Out of stock. This item will not be added.']; }
        $existing = self::cart_quantity((int) $p->get_stock_managed_by_id());
        $available = null;
        if ($p->managing_stock()) {
            $stock_product = wc_get_product($p->get_stock_managed_by_id());
            if (!$stock_product || !is_numeric($stock_product->get_stock_quantity())) { return $bad; }
            $held = function_exists('wc_get_held_stock_quantity') ? (float) wc_get_held_stock_quantity($stock_product) : 0;
            $available = max(0, (int) floor((float) $stock_product->get_stock_quantity() - $held - $existing));
        }
        if ($p->is_sold_individually()) { $available = min($available ?? 1, max(0, 1 - (int) ceil($existing))); }
        if ($available === 0) { return ['eligible' => false, 'available' => 0, 'status' => 'out', 'reason' => 'No additional stock is available after items already in your cart.']; }
        if ($addition < 1 || $addition > Parser::MAX_QUANTITY) { return ['eligible' => false, 'available' => $available, 'status' => 'invalid', 'reason' => 'Enter a positive whole-number quantity.']; }
        if ($available !== null && $addition > $available) { return ['eligible' => false, 'available' => $available, 'status' => 'insufficient', 'reason' => 'Only ' . $available . ' available to add. Accept this quantity or remove the item.']; }
        return ['eligible' => true, 'available' => $available, 'status' => 'ready', 'reason' => 'Ready to add.'];
    }
    public static function review(array $rows, array $known = []): array {
        $result = [];
        foreach ($rows as $i => $row) {
            $q = Parser::quantity((string) $row['quantity']);
            $id = $row['error'] === null && $q ? ($known['sku:'.$row['sku']] ?? wc_get_product_id_by_sku($row['sku'])) : 0;
            $p = $id ? wc_get_product($id) : false;
            if ($p && $p->get_sku() !== $row['sku']) { $p = false; $id = 0; }
            $state = ['eligible' => false, 'available' => null, 'status' => 'invalid', 'reason' => $row['error'] ?? 'Enter a valid quantity.'];
            if ($row['error'] === null && $q) {
                $state = $p ? self::check((int) $id, $q) : self::check(0, $q);
            }
            // Never reveal names/prices of role-restricted products.
            $display = $p && $state['status'] !== 'unavailable';
            $result[] = array_merge($row, $state, [
                'id' => (string) $i, 'product_id' => $display ? (int) $id : 0,
                'name' => $display ? $p->get_name() : '',
                'existing_cart_quantity' => $display ? self::item_cart_quantity((int) $id) : 0.0,
                'requested' => (string) ($row['original_quantity'] ?? $row['quantity']),
                'accepted' => $state['eligible'] ? $q : 0,
                'selected' => $state['eligible'],
                'price' => $display && $q ? Pricing::preview($p, (int) ceil(self::cart_quantity((int) $p->get_stock_managed_by_id()) + $q)) : ['known' => false, 'unit_ex_tax' => null, 'bulk_applied' => false],
            ]);
        }
        return $result;
    }
}
