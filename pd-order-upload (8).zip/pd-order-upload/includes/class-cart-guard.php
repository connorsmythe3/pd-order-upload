<?php
namespace PureDistilling\OrderUpload;

/** Connection-owned lock acquired before WooCommerce loads any signed-in cart.
 * Normal frontend, AJAX and Store API requests participate, not just upload actions.
 * MySQL/MariaDB releases the lock on connection loss, even after a hard worker kill.
 */
final class CartGuard {
    private static bool $registered = false;
    private static ?string $key = null;
    private static ?int $connection = null;
    public static function register(): void {
        self::$registered = true;
        add_action('init', [self::class, 'early'], -1000);
        add_action('shutdown', [self::class, 'release'], PHP_INT_MAX);
    }
    public static function early(): void {
        if (!function_exists('WC') || !WC()) { return; }
        if (is_admin() && !wp_doing_ajax()) { return; }
        try {
            $account=null;
            // Match WooCommerce's session-handler selection: this header only
            // identifies a cart on Store API routes, never ordinary AJAX/forms.
            $store_api=is_callable([WC(),'is_store_api_request']) && WC()->is_store_api_request();
            if (!$store_api && isset($_GET['rest_route']) && is_string($_GET['rest_route'])) {
                $store_api=str_starts_with(rawurldecode(esc_url_raw(wp_unslash($_GET['rest_route']))),'/wc/store/');
            }
            if ($store_api && !empty($_SERVER['HTTP_CART_TOKEN'])) {
                $utility='Automattic\\WooCommerce\\StoreApi\\Utilities\\CartTokenUtils';
                if (!is_string($_SERVER['HTTP_CART_TOKEN']) || strlen($_SERVER['HTTP_CART_TOKEN'])>4096 || !is_callable([$utility,'get_cart_token_payload'])) { throw new UploadException('Cart token compatibility needs verification. Use your signed-in ordering portal.'); }
                $payload=$utility::get_cart_token_payload($_SERVER['HTTP_CART_TOKEN']);
                $id=$payload['user_id']??'';
                if ((is_string($id) || is_int($id)) && ctype_digit((string)$id) && (int)$id>0) { $account=(int)$id; }
            }
            if ($account===null) {
                if (!is_user_logged_in() || !Access::roles()) { return; }
                $account=get_current_user_id();
            }
            self::acquire($account);
        }
        catch (UploadException $e) {
            nocache_headers();
            if (wp_doing_ajax() || isset($_SERVER['HTTP_CART_TOKEN']) || (defined('REST_REQUEST') && REST_REQUEST)) { wp_send_json_error(['message'=>$e->getMessage()], 409); }
            wp_die(esc_html($e->getMessage()), 'Ordering temporarily busy', ['response'=>409]);
        }
    }
    public static function acquire(?int $account=null): void {
        if (self::$key !== null) { self::assert_owned(); return; }
        global $wpdb;
        $name = 'pdou_' . substr(hash('sha256', (defined('DB_NAME') ? DB_NAME : '') . '|' . ($wpdb->prefix ?? '') . '|' . ($account??get_current_user_id())), 0, 56);
        $got = $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 2)', $name));
        if ((string) $got !== '1') { throw new UploadException('Your cart is being updated in another request. Wait a moment, then try again.', 'throttled'); }
        $connection = (int) $wpdb->get_var('SELECT CONNECTION_ID()');
        if ($connection < 1) { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name)); throw new UploadException('Cart protection is unavailable. Please try again later.'); }
        self::$key = $name; self::$connection = $connection;
    }
    public static function assert_owned(): void {
        // Isolated unit fixtures do not register WordPress lifecycle hooks.
        if (!self::$registered) { return; }
        if (self::$key === null) { throw new UploadException('Cart protection is unavailable. Refresh the page before ordering.'); }
        global $wpdb;
        if ((int) $wpdb->get_var($wpdb->prepare('SELECT IS_USED_LOCK(%s)', self::$key)) !== self::$connection
            || (int) $wpdb->get_var('SELECT CONNECTION_ID()') !== self::$connection) {
            throw new UploadException('The cart connection changed. Check your cart before trying again.');
        }
    }
    public static function active(): bool {
        if (!self::$registered || self::$key === null) { return false; }
        self::assert_owned();
        return true;
    }
    public static function release(): void {
        if (self::$key === null) { return; }
        global $wpdb;
        try { $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', self::$key)); }
        catch (\Throwable $e) { /* Connection termination is the final release boundary. */ }
        self::$key = null; self::$connection = null;
    }
}
