<?php
namespace PureDistilling\OrderUpload;
final class AuditAdmin {
    public static function register(): void {
        add_action('admin_menu', static function() { add_submenu_page('woocommerce', 'Order Upload Log', 'Order Upload Log', 'manage_options', 'pdou-upload-log', [self::class, 'render']); });
        add_action('admin_post_pdou_log_settings', [self::class, 'save']);
        add_action('admin_post_pdou_captcha_settings', [self::class, 'save_captcha']);
        add_action('admin_post_pdou_log_test', [self::class, 'test_email']);
    }
    private static function authorize(): void { if (!current_user_can('manage_options')) { wp_die('You do not have permission to view the upload log.'); } }
    public static function save(): void {
        self::authorize(); if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { wp_die('Submit this action from the upload log page.'); } check_admin_referer('pdou_log_settings');
        $input = wp_unslash($_POST);
        $cfg = AuditLog::validate_settings(['retention_days' => $input['retention_days'] ?? 90, 'email' => $input['email'] ?? '', 'alerts' => $input['alerts'] ?? false, 'delete_on_uninstall'=>$input['delete_on_uninstall'] ?? false]);
        update_option('pdou_log_settings', $cfg, false);
        wp_safe_redirect(add_query_arg(['page'=>'pdou-upload-log','saved'=>1], admin_url('admin.php'))); exit;
    }
    public static function save_captcha(): void {
        self::authorize();
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { wp_die('Submit this action from the upload log page.'); }
        check_admin_referer('pdou_captcha_settings');
        $cfg = Captcha::validate_settings(wp_unslash($_POST), Captcha::settings());
        update_option('pdou_captcha_settings', $cfg, false);
        wp_safe_redirect(add_query_arg(['page'=>'pdou-upload-log','captcha_saved'=>1], admin_url('admin.php'))); exit;
    }
    public static function test_email(): void {
        self::authorize(); if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { wp_die('Submit this action from the upload log page.'); } check_admin_referer('pdou_log_test');
        $cfg = AuditLog::settings();
        $ok = $cfg['email'] !== '' && wp_mail($cfg['email'], 'Order upload alert test', "This is a test from your WordPress order upload log. No file is attached.\n\n" . admin_url('admin.php?page=pdou-upload-log'), ['Content-Type: text/plain; charset=UTF-8']);
        wp_safe_redirect(add_query_arg(['page'=>'pdou-upload-log','test'=>$ok ? 'sent' : 'failed'], admin_url('admin.php'))); exit;
    }
    private static function number(string $key, int $max = PHP_INT_MAX): int { $s = $_GET[$key] ?? ''; return is_scalar($s) && ctype_digit((string)$s) ? min($max, (int)$s) : 0; }
    public static function render(): void {
        self::authorize(); global $wpdb;
        echo '<div class="wrap"><h1>Order Upload Log</h1><p>Private upload activity and order results. Times below are UTC. Original files are deleted after processing.</p>';
        if (get_option('pdou_log_failed')) { echo '<div class="notice notice-error"><p>Some log records could not be saved. Ask your developer to check database permissions and the upload log table.</p></div>'; }
        if (get_option('pdou_alert_failed')) { echo '<div class="notice notice-warning"><p>An alert could not be handed to the email system. Check your SMTP setup.</p></div>'; }
        if (isset($_GET['saved'])) { echo '<div class="notice notice-success"><p>Settings saved. Email alerts require a valid recipient and the enabled checkbox.</p></div>'; }
        if (isset($_GET['test'])) { echo '<div class="notice notice-info"><p>' . (($_GET['test'] === 'sent') ? 'Test email handed to WordPress. Check your inbox and spam folder; this does not verify delivery.' : 'Test email could not be sent. Save a valid recipient and check SMTP.') . '</p></div>'; }
        if (isset($_GET['captcha_saved'])) { echo '<div class="notice notice-success"><p>reCAPTCHA settings saved.</p></div>'; }
        $queue=get_option('pdou_alert_queue_status',[]); $cleanup=get_option('pdou_log_cleanup_status',[]);
        if (is_array($queue) && isset($queue['pending'])) { echo '<p>Pending background alerts: '.(int)$queue['pending'].'.</p>'; }
        if (is_array($cleanup) && !empty($cleanup['oldest_expired'])) { echo '<div class="notice notice-warning"><p>Log cleanup has a backlog. Oldest expired record (UTC): '.esc_html(gmdate('Y-m-d H:i:s',(int)$cleanup['oldest_expired'])).'. Catch-up jobs are scheduled.</p></div>'; }
        $id = self::number('entry');
        if ($id) { self::detail($id); }
        else { self::listing(); self::settings(); }
        echo '</div>';
    }
    private static function listing(): void {
        global $wpdb; $page = max(1, self::number('paged', 10000)); $uid = self::number('user');
        $event = is_string($_GET['event'] ?? null) && in_array($_GET['event'], AuditLog::EVENTS, true) ? $_GET['event'] : '';
        $sql = 'SELECT id,created_at,user_id,event,file_name,reason FROM ' . AuditLog::table() . ' WHERE 1=1'; $args = [];
        if ($uid) { $sql .= ' AND user_id = %d'; $args[] = $uid; }
        if ($event !== '') { $sql .= ' AND event = %s'; $args[] = $event; }
        $sql .= ' ORDER BY id DESC LIMIT 26 OFFSET %d'; $args[] = ($page-1)*25;
        $records = $wpdb->get_results($wpdb->prepare($sql, ...$args), ARRAY_A) ?: [];
        echo '<form method="get"><input type="hidden" name="page" value="pdou-upload-log"><label>Customer ID <input type="number" min="1" name="user" value="'.($uid ? esc_attr((string)$uid) : '').'"></label> <label>Outcome <select name="event"><option value="">All outcomes</option>';
        foreach (AuditLog::EVENTS as $e) { echo '<option value="'.esc_attr($e).'"'.($event === $e ? ' selected' : '').'>'.esc_html(ucfirst($e)).'</option>'; }
        echo '</select></label> <button class="button">Filter</button></form><p>Showing up to 25 records per page. Repeated cooldown blocks are grouped to one log record per account every two minutes.</p><table class="widefat striped"><thead><tr><th>Time (UTC)</th><th>Customer</th><th>Outcome</th><th>File</th><th>Reason</th><th>Details</th></tr></thead><tbody>';
        foreach (array_slice($records,0,25) as $r) {
            $user = get_userdata((int)$r['user_id']); $url = add_query_arg(['page'=>'pdou-upload-log','entry'=>(int)$r['id']], admin_url('admin.php'));
            echo '<tr><td>'.esc_html(gmdate('Y-m-d H:i:s',(int)$r['created_at'])).'</td><td>'.esc_html(($user->user_login ?? 'Deleted account').' (#'.$r['user_id'].')').'</td><td>'.esc_html(ucfirst($r['event'])).'</td><td>'.esc_html($r['file_name']).'</td><td>'.esc_html($r['reason']).'</td><td><a href="'.esc_url($url).'">View</a></td></tr>';
        }
        if (!$records) { echo '<tr><td colspan="6">No upload activity matches these filters.</td></tr>'; }
        echo '</tbody></table><p>';
        foreach (['Previous'=>$page-1,'Next'=>$page+1] as $label=>$n) { if ($n < 1 || ($label === 'Next' && count($records)<26)) { continue; } echo '<a class="button" href="'.esc_url(add_query_arg(['page'=>'pdou-upload-log','paged'=>$n,'user'=>$uid,'event'=>$event], admin_url('admin.php'))).'">'.esc_html($label).'</a> '; }
        echo '</p>';
    }
    private static function detail(int $id): void {
        global $wpdb; $r = $wpdb->get_row($wpdb->prepare('SELECT * FROM '.AuditLog::table().' WHERE id = %d', $id), ARRAY_A);
        echo '<p><a href="'.esc_url(admin_url('admin.php?page=pdou-upload-log')).'">&larr; Back to upload log</a></p>';
        if (!$r) { echo '<p>This record was not found or has expired.</p>'; return; }
        $user = get_userdata((int)$r['user_id']);
        echo '<h2>Record #'.(int)$id.'</h2><p>Customer: '.esc_html(($user->user_login ?? 'Deleted account').' (#'.$r['user_id'].')').'<br>Time (UTC): '.esc_html(gmdate('Y-m-d H:i:s',(int)$r['created_at'])).'<br>Outcome: '.esc_html($r['event']).'<br>Filename: '.esc_html($r['file_name']).'<br>Size: '.esc_html($r['file_size']).' bytes<br>SHA-256: <code>'.esc_html($r['file_hash']).'</code><br>Reason: '.esc_html($r['reason']).'</p>';
        if ($r['upload_ref'] !== '') {
            $linked = $wpdb->get_results($wpdb->prepare('SELECT id,event,file_name FROM '.AuditLog::table().' WHERE upload_ref = %s AND user_id = %d ORDER BY id DESC LIMIT 50', $r['upload_ref'], (int)$r['user_id']), ARRAY_A) ?: [];
            echo '<p>Related activity: ';
            foreach ($linked as $item) { echo '<a href="'.esc_url(add_query_arg(['page'=>'pdou-upload-log','entry'=>(int)$item['id']], admin_url('admin.php'))).'">'.esc_html($item['event'].' #'.$item['id'].' '.$item['file_name']).'</a> '; }
            echo '</p>';
        }
        $decoded = json_decode($r['rows_json'], true); $rows = is_array($decoded) ? $decoded : [];
        if (isset($decoded['rows']) && is_array($decoded['rows'])) {
            $rows = $decoded['rows'];
            echo '<p>Added quantity: '.(int)($decoded['totals']['added']??0).'; uncertain rows: '.(int)($decoded['outcomes']['uncertain']??0).'; additional events grouped: '.(int)($decoded['coalesced_events']??0).'.</p>';
            echo '<p>Stored '.(int)$decoded['stored_rows'].' of '.(int)$decoded['total_rows'].' rows. Omitted: '.(int)$decoded['omitted_rows'].'. Truncated fields: '.(int)($decoded['fields_truncated']??0).'; omitted source coordinates: '.(int)($decoded['source_rows_omitted']??0).'.'.(!empty($decoded['budget_exhausted']) ? ' Account detailed-log budget exhausted.' : '').' Bounded allowlisted rows SHA-256: <code>'.esc_html($decoded['sha256']).'</code></p>';
        }
        echo '<table class="widefat striped"><thead><tr><th>Source rows</th><th>SKU</th><th>Product</th><th>Requested</th><th>Accepted</th><th>Added</th><th>Status / reason</th></tr></thead><tbody>';
        foreach ($rows as $row) { echo '<tr>'; foreach ([implode(', ', $row['rows'] ?? []), $row['sku'] ?? '', $row['name'] ?? '', $row['requested'] ?? $row['quantity'] ?? '', $row['accepted'] ?? '', $row['added'] ?? '', ($row['status'] ?? '').' '.($row['reason'] ?? '')] as $v) { echo '<td>'.esc_html($v).'</td>'; } echo '</tr>'; }
        if (!$rows) { echo '<tr><td colspan="7">No parsed order rows were available for this event.</td></tr>'; }
        echo '</tbody></table>';
    }
    private static function captcha_settings(): void {
        if (!class_exists(Captcha::class)) { return; }
        $cfg = Captcha::settings();
        echo '<hr><h2>reCAPTCHA — Upload Order</h2><p>Use classic reCAPTCHA v2 “I’m not a robot” checkbox keys. Add your live and staging domains in the Google console. Protection starts when you enable it and save.</p>';
        if ($cfg['enabled'] && ($cfg['site_key'] === '' || $cfg['secret_key'] === '')) { echo '<div class="notice notice-error"><p>reCAPTCHA is enabled but keys are missing or invalid. Uploads will be blocked until both keys are saved, or you disable it.</p></div>'; }
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pdou_captcha_settings">'; wp_nonce_field('pdou_captcha_settings');
        echo '<p><label><input type="checkbox" name="enabled" value="1"'.($cfg['enabled'] ? ' checked' : '').'> Require reCAPTCHA for order uploads</label></p><p><label>Site key <input type="text" name="site_key" class="regular-text" maxlength="200" value="'.esc_attr($cfg['site_key']).'"></label></p><p><label>Secret key <input type="password" name="secret_key" class="regular-text" maxlength="200" autocomplete="new-password" value="" placeholder="'.esc_attr($cfg['secret_key'] !== '' ? 'Saved — leave blank to keep' : 'Enter secret key').'"></label></p><p><label><input type="checkbox" name="clear_secret" value="1"> Delete the saved secret key</label></p><p>The saved secret is never displayed. When enabled, verification errors block uploads. Existing cart confirmation and normal ordering remain available. Google’s widget contacts Google when the upload popup is opened.</p><button class="button button-primary">Save reCAPTCHA settings</button></form>';
    }
    private static function settings(): void {
        self::captcha_settings();
        $cfg = AuditLog::settings();
        echo '<hr><h2>Log and alert settings</h2><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pdou_log_settings">'; wp_nonce_field('pdou_log_settings');
        echo '<p><label>Keep log records for <input type="number" min="7" max="365" name="retention_days" value="'.esc_attr((string)$cfg['retention_days']).'"> days (7–365).</label></p><p><label>Alert email <input type="email" name="email" maxlength="254" value="'.esc_attr($cfg['email']).'"></label></p><p><label><input type="checkbox" name="alerts" value="1"'.($cfg['alerts'] ? ' checked' : '').'> Enable security activity alerts</label></p><p>Background alert for suspicious-file rejection; alert after three failed or throttled attempts in ten minutes. At most one alert per account every ten minutes. Stock and unknown-SKU rows do not trigger email. No upload attachments. Uses your WordPress/SMTP email setup.</p><p><label><input type="checkbox" name="delete_on_uninstall" value="1"'.($cfg['delete_on_uninstall'] ? ' checked' : '').'> Delete plugin records, settings and saved reCAPTCHA secret when the plugin is uninstalled</label></p><p>Deactivation keeps records. Backups may retain deleted records.</p><button class="button button-primary">Save settings</button></form>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="pdou_log_test">'; wp_nonce_field('pdou_log_test'); echo '<p><button class="button"'.($cfg['email'] === '' ? ' disabled' : '').'>Send test email to saved recipient</button></p></form><p>Expired logs are deleted in hourly WordPress cron batches. Backups may retain older records. Administrators can change this log; it is not tamper-proof evidence.</p>';
    }
}
