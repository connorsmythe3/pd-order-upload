<?php
namespace PureDistilling\OrderUpload;
/** Only deliberately written messages may be shown to customers. */
final class UploadException extends \RuntimeException {
    public function __construct(string $message, public readonly string $category = 'validation') { parent::__construct($message); }
}
