<?php
namespace PureDistilling\OrderUpload;
final class Pricing {
    public static function preview(object $product, int $combined_quantity): array {
        // No verified quantity-preview API supplied for this site's Premium version.
        // Never mutate the live cart or approximate global/category pricing rules.
        return ['known' => false, 'unit_ex_tax' => null, 'bulk_applied' => false];
    }
    public static function actual(array $item): array {
        $result = ['known' => false, 'unit_ex_tax' => null, 'bulk_applied' => false];
        $quantity = (float) ($item['quantity'] ?? 0); $subtotal = $item['line_subtotal'] ?? null;
        if ($quantity <= 0 || !is_numeric($subtotal)) { return $result; }
        $unit = (float) $subtotal / $quantity; $decimals = wc_get_price_decimals();
        $result['known'] = true; $result['unit_ex_tax'] = number_format($unit, $decimals, '.', '');
        $p = $item['data'] ?? null; $roles = Access::roles();
        if (!$p || !$roles || $p->get_meta('wwpp_post_meta_enable_quantity_discount_rule', true) !== 'yes' || !is_callable(['WWP_Wholesale_Prices', 'get_product_wholesale_price_on_shop_v3'])) { return $result; }
        $price = \WWP_Wholesale_Prices::get_product_wholesale_price_on_shop_v3($p->get_id(), $roles);
        $base = $price['wholesale_price_with_no_tax'] ?? null; $raw = $price['wholesale_price_raw'] ?? null;
        if (!is_numeric($base) || !is_numeric($raw) || $base <= 0 || $raw <= 0) { return $result; }
        $tolerance = 0.5 * pow(10, -$decimals) + 0.000001;
        if ($unit >= (float) $base - $tolerance || $unit < 0) { return $result; }
        $rules = $p->get_meta('wwpp_post_meta_quantity_discount_rule_mapping', true);
        if (is_string($rules)) { $rules = json_decode($rules, true); }
        foreach (is_array($rules) ? $rules : [] as $r) {
            if (!is_array($r) || !in_array($r['wholesale_role'] ?? '', $roles, true) || !is_numeric($r['start_qty'] ?? null) || !is_numeric($r['wholesale_price'] ?? null)) { continue; }
            $start = (float) $r['start_qty']; $end = $r['end_qty'] ?? ''; $value = (float) $r['wholesale_price'];
            if ($start <= 0 || $quantity < $start || ($end !== '' && (!is_numeric($end) || (float) $end < $start || $quantity > (float) $end))) { continue; }
            if (($r['price_type'] ?? '') === 'percent-price' && $value >= 0 && $value <= 100) { $expected = $base * (1 - $value / 100); }
            elseif (($r['price_type'] ?? '') === 'fixed-price' && $value >= 0) { $expected = $value * $base / $raw; }
            else { continue; }
            if (abs($unit - $expected) <= $tolerance) { $result['bulk_applied'] = true; break; }
        }
        return $result;
    }
}
