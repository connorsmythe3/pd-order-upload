<?php
namespace PureDistilling\OrderUpload;
final class Access {
    public static function roles(): array {
        global $wc_wholesale_prices;
        if (!is_user_logged_in() || !isset($wc_wholesale_prices->wwp_wholesale_roles) || !is_callable([$wc_wholesale_prices->wwp_wholesale_roles, 'getUserWholesaleRole'])) { return []; }
        return array_values(array_filter((array) $wc_wholesale_prices->wwp_wholesale_roles->getUserWholesaleRole(), static fn($v) => is_string($v) && $v !== ''));
    }
    public static function assert_request(bool $bootstrap = false): void {
        if (!is_user_logged_in() || !self::roles()) { throw new UploadException('Sign in with your wholesale account to upload an order.'); }
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || ($_SERVER['HTTP_X_PD_UPLOAD'] ?? '') !== '1') { throw new UploadException('Unsupported request. Refresh the page and try again.'); }
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        if ($origin !== '') {
            $source = wp_parse_url($origin); $allowed = [wp_parse_url(home_url()), wp_parse_url(admin_url())]; $match = false;
            foreach ($allowed as $a) {
                if ($source && $a && ($source['scheme'] ?? '') === ($a['scheme'] ?? '') && ($source['host'] ?? '') === ($a['host'] ?? '') && ($source['port'] ?? null) === ($a['port'] ?? null)) { $match = true; }
            }
            if (!$match) { throw new UploadException('This request must come from the ordering portal.'); }
        }
        if (!$bootstrap && (!isset($_POST['nonce']) || !is_string($_POST['nonce']) || !wp_verify_nonce(wp_unslash($_POST['nonce']), 'pd_order_upload'))) { throw new UploadException('Your session has expired. Refresh the page and try again.'); }
        if (!function_exists('WC') || !WC()) { throw new UploadException('Ordering is temporarily unavailable.'); }
        if ((!WC()->session || !WC()->cart) && function_exists('wc_load_cart')) { wc_load_cart(); }
        if (!WC()->session || !WC()->cart) { throw new UploadException('Your cart is unavailable. Refresh the page and try again.'); }
        WC()->session->set_customer_session_cookie(true);
    }
}
