<?php
/** Uninstallation retains records unless an administrator explicitly elected deletion. */
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
foreach (['pdou_cleanup','pdou_log_cleanup_catchup','pdou_cleanup_catchup','pdou_alert_queue'] as $hook) { wp_clear_scheduled_hook($hook); }
$settings=get_option('pdou_log_settings',[]);
if (!is_array($settings) || empty($settings['delete_on_uninstall'])) { return; }
global $wpdb;
$wpdb->query('DROP TABLE IF EXISTS '.$wpdb->prefix.'pdou_log');
// Includes saved CAPTCHA secret, review/lock data, budgets, queued alerts and diagnostics.
do {
    $names=$wpdb->get_col($wpdb->prepare('SELECT option_name FROM '.$wpdb->options.' WHERE option_name LIKE %s LIMIT 50',$wpdb->esc_like('pdou_').'%'));
    $removed=0;
    foreach (is_array($names) ? $names : [] as $name) { if (delete_option($name)) { ++$removed; } }
} while ($removed>0 && count($names)===50);
