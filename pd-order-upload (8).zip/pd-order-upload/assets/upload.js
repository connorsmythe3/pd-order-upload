/* Pure Distilling Order Upload: scoped UI, optional Google reCAPTCHA and no HTML interpolation. */
(() => {
  'use strict';
  let dialogSequence = 0, captchaAPI = null;
  const loadCaptcha = () => {
    if (window.grecaptcha?.render) return Promise.resolve(window.grecaptcha);
    if (captchaAPI) return captchaAPI;
    captchaAPI = new Promise((resolve, reject) => {
      let timer, poll;
      const finish = error => { clearTimeout(timer); clearInterval(poll); if (error) { captchaAPI = null; reject(error); } else resolve(window.grecaptcha); };
      const ready = () => { if (window.grecaptcha?.render) finish(); };
      poll = setInterval(ready, 100);
      timer = setTimeout(() => finish(new Error('Human verification could not load. Refresh the page or use the order form.')), 12000);
      const existing = Array.from(document.scripts).some(s => /^https:\/\/(?:www\.google\.com|www\.recaptcha\.net)\/recaptcha\/api\.js(?:[?]|$)/.test(s.src));
      if (!existing) {
        window.PDOURecaptchaReady = ready;
        const script = document.createElement('script'); script.src = 'https://www.google.com/recaptcha/api.js?render=explicit&onload=PDOURecaptchaReady'; script.async = true; script.defer = true;
        script.onerror = () => finish(new Error('Human verification could not load. Refresh the page or use the order form.'));
        document.head.append(script);
      }
    });
    return captchaAPI;
  };
  const el = (tag, text, cls) => { const n = document.createElement(tag); if (text !== undefined) n.textContent = text; if (cls) n.className = cls; return n; };
  document.querySelectorAll('.pd-order-upload').forEach(root => {
    if (root.dataset.initialised) return;
    root.dataset.initialised = '1';
    const content = root.querySelector('.pdou-content'), status = root.querySelector('.pdou-status');
    const dialog = root.closest('.pdou-dialog');
    const launch = dialog?.closest('.pdou-widget')?.querySelector('.pdou-launch');
    let nonce = '', review = null, busy = false, dirty = false, done = false, cartURL = '';
    let captchaConfig = {enabled:false}, captchaId = null, captchaSolved = false, captchaLayer = null, challengeObserver = null;
    const say = (message, error = false) => { status.textContent = message; status.classList.toggle('pdou-error', error); };
    const button = (text, action, cls = '') => { const b = el('button', text, 'pdou-button ' + cls); b.type = 'button'; b.dataset.action = action; return b; };
    const money = (amount, currency) => { try { return new Intl.NumberFormat('en-AU', {style:'currency',currency:currency || 'AUD'}).format(Number(amount)); } catch (_) { return `${currency || 'AUD'} ${amount}`; } };
    const setBusy = value => {
      busy = value; root.setAttribute('aria-busy', String(value));
      root.querySelectorAll('button,input').forEach(n => { n.disabled = value || n.dataset.unavailable === '1'; });
      updateButtons();
    };
    const updateButtons = () => {
      const upload = content.querySelector('[data-action=upload]'); if (upload) upload.disabled = busy || !nonce || (captchaConfig.enabled && !captchaSolved);
      const confirm = content.querySelector('[data-action=confirm]');
      if (confirm) confirm.disabled = busy || dirty || done || !Array.from(content.querySelectorAll('[data-field=selected]')).some(c => c.checked && !c.disabled);
      const revise = content.querySelector('[data-action=revise]'); if (revise) revise.disabled = busy || done || !dirty;
    };
    const resetCaptcha = () => {
      captchaSolved = false;
      if (captchaId !== null && window.grecaptcha?.reset) { try { window.grecaptcha.reset(captchaId); } catch (_) {} }
      updateButtons();
    };
    // Google's image challenge is appended to body. Keep only this widget's
    // challenge in the modal DOM, then raise its transparent host into the top layer.
    const watchChallenge = () => {
      if (!dialog || !captchaConfig.enabled || challengeObserver) return;
      challengeObserver = new MutationObserver(() => {
        if (!dialog.open) return;
        for (const frame of document.querySelectorAll('iframe[src]')) {
          let url; try { url = new URL(frame.src); } catch (_) { continue; }
          const anchor = content.querySelector('.pdou-captcha iframe[name^="a-"]');
          if (!anchor || frame.name !== 'c-' + anchor.name.slice(2)) continue;
          if (!['www.google.com','www.recaptcha.net'].includes(url.hostname) || !/^\/recaptcha\/api2\/bframe$/.test(url.pathname) || url.searchParams.get('k') !== captchaConfig.site_key || dialog.contains(frame)) continue;
          let node = frame; while (node.parentElement && node.parentElement !== document.body) node = node.parentElement;
          if (node.parentElement !== document.body || node.tagName !== 'DIV' || node.contains(root) || node.querySelectorAll('iframe').length > 2) continue;
          if (!captchaLayer) { captchaLayer = el('div',undefined,'pdou-captcha-layer'); captchaLayer.setAttribute('popover','manual'); dialog.append(captchaLayer); }
          captchaLayer.append(node);
          if (captchaLayer.showPopover && !captchaLayer.matches(':popover-open')) captchaLayer.showPopover();
        }
      });
      challengeObserver.observe(document.body,{childList:true,subtree:true});
    };
    const mountCaptcha = async () => {
      if (!captchaConfig.enabled || !content.querySelector('input[type=file]')) return;
      if (!captchaConfig.site_key) { say('Human verification is unavailable. Please use the order form or contact us.',true); updateButtons(); return; }
      let box = content.querySelector('.pdou-captcha');
      if (!box) { box = el('div',undefined,'pdou-captcha'); content.querySelector('.pdou-file-box').append(box); }
      try {
        const api = await loadCaptcha();
        if (!box.isConnected || !content.contains(box)) return;
        watchChallenge();
        captchaId = api.render(box,{sitekey:captchaConfig.site_key,size:root.clientWidth && root.clientWidth<360?'compact':'normal',callback:()=>{captchaSolved=true;updateButtons();},'expired-callback':()=>{captchaSolved=false;updateButtons();say('Complete the human verification again before uploading.',true);},'error-callback':()=>{captchaSolved=false;updateButtons();say('Human verification could not be completed. Try again or use the order form.',true);}});
      } catch (e) { say(e.message || 'Human verification is unavailable. Please use the order form.',true); }
      updateButtons();
    };
    const request = async (action, values = {}) => {
      const data = new FormData(); data.set('action', 'pdou_' + action); if (nonce) data.set('nonce', nonce);
      for (const [key, value] of Object.entries(values)) data.set(key, value);
      const response = await fetch(root.dataset.endpoint, {method:'POST',credentials:'same-origin',headers:{'X-PD-Upload':'1'},body:data});
      let json; try { json = await response.json(); } catch (_) { throw new Error(['confirm','advance','recover'].includes(action)?'Ordering was interrupted. Check your cart, then reopen Upload Order to review saved progress.':'Your session could not be checked. Refresh the page and sign in again.'); }
      if (!response.ok || !json || json.success !== true) throw new Error(json?.data?.message || 'Sign in with your wholesale account, then refresh this page.');
      return json.data;
    };
    const perform = async (message, work) => {
      if (busy) return;
      setBusy(true); say(message);
      try { await work(); } catch (e) { say(e.message || 'The request failed. Check your cart before retrying an addition.', true); }
      finally { setBusy(false); }
    };
    const actions = () => {
      const bar = el('div', undefined, 'pdou-actions');
      bar.append(button('Update review', 'revise', 'pdou-secondary'), button('Add selected items to cart', 'confirm'), button('Download issues report', 'report', 'pdou-secondary'), button('Upload another file', 'reset', 'pdou-text-button'));
      return bar;
    };
    const start = () => {
      resetCaptcha(); captchaId = null;
      review = null; dirty = false; done = false; content.replaceChildren();
      const label = el('label', 'Choose your order file', 'pdou-file-label');
      const file = el('input'); file.type='file'; file.accept='.csv,.xlsx'; file.setAttribute('aria-label','Order spreadsheet'); label.append(file);
      const box = el('div', undefined, 'pdou-file-box'); box.append(label, el('p','CSV or Excel .xlsx','pdou-muted'));
      const bar = el('div', undefined, 'pdou-actions'); bar.append(button('Upload and review','upload'));
      if (root.dataset.template) { const link = el('a','Download Excel template','pdou-template'); link.href=root.dataset.template; link.download='PD-order-template.xlsx'; bar.append(link); }
      content.append(box,bar,el('p','Use SKU and Quantity columns. The Excel template keeps long SKUs and leading zeros as text.','pdou-muted'),el('p',"SKU's must match the SKU displayed online, refer to Products sheet for the correct SKU's",'pdou-muted'));
      if (nonce) mountCaptcha();
      updateButtons();
    };
    const field = (tag, label, row, name, value) => {
      const input = el(tag); input.dataset.field=name; input.setAttribute('aria-label',`${label} for row ${row.rows.join(', ')}`);
      if (tag === 'input') { input.type = name === 'selected' ? 'checkbox' : 'text'; if (name === 'selected') input.checked = Boolean(value); else input.value = String(value); }
      return input;
    };
    const td = (label, node) => { const cell = el('td'); cell.dataset.label=label; if (typeof node==='string') cell.textContent=node; else cell.append(node); return cell; };
    const showReview = next => {
      review=next; dirty=false; done=false; content.replaceChildren();
      const ready=next.rows.filter(r=>r.eligible).length;
      content.append(el('h3',`${ready} item${ready===1?'':'s'} ready · ${next.rows.length-ready} need attention`,'pdou-summary'), el('p','Confirm the quantities below. Stock reductions need your approval. Final wholesale prices and bulk discounts are calculated in cart.','pdou-muted'));
      const wrap=el('div',undefined,'pdou-table-wrap'),table=el('table',undefined,'pdou-table');
      const caption=el('caption','Uploaded order review','pdou-screen-reader'); table.append(caption);
      const head=el('thead'),hr=el('tr');['Add','Product / SKU','Requested','Quantity to add','Status'].forEach(s=>{const th=el('th',s);th.scope='col';hr.append(th);});head.append(hr);table.append(head);
      const body=el('tbody');
      next.rows.forEach(r=>{
        const tr=el('tr',undefined,'pdou-row');tr.dataset.row=r.id;
        const select=field('input','Select',r,'selected',r.selected);if(!r.eligible){select.disabled=true;select.dataset.unavailable='1';}
        tr.append(td('Add',select));
        const product=el('div',undefined,'pdou-product');product.append(el('strong',r.name||'Check SKU'));
        const sku=field('input','SKU',r,'sku',r.sku);sku.maxLength=512;sku.className='pdou-sku';product.append(sku,el('small',`File row${r.rows.length===1?'':'s'} ${r.rows.join(', ')}`,'pdou-muted'));
        if (Number(r.existing_cart_quantity)>0) product.append(el('small',`Already in your cart: ${r.existing_cart_quantity}. Adding this item increases your existing quantity.`,'pdou-cart-warning'));
        tr.append(td('Product / SKU',product),td('Requested',String(r.requested)));
        const quantity=field('input','Quantity',r,'quantity',r.accepted>0?r.accepted:r.quantity);quantity.inputMode='numeric';quantity.maxLength=7;quantity.className='pdou-quantity';tr.append(td('Quantity to add',quantity));
        const state=el('div',undefined,`pdou-state pdou-${r.status}`);state.append(el('span',r.reason));
        if(r.status==='insufficient'&&r.available>0){state.append(button(`Use ${r.available}`,'available','pdou-secondary'));}
        if(!r.eligible)state.append(button('Remove','remove','pdou-text-button'));
        tr.append(td('Status',state));body.append(tr);
      });table.append(body);wrap.append(table);content.append(wrap,actions());updateButtons();
    };
    const collect = () => Array.from(content.querySelectorAll('.pdou-row')).map(tr=>({id:tr.dataset.row,sku:tr.querySelector('[data-field=sku]').value,quantity:tr.querySelector('[data-field=quantity]').value,selected:tr.querySelector('[data-field=selected]').checked}));
    const revise = async () => {const data=await request('revise',{token:review.token,version:String(review.version),data:JSON.stringify(collect())});showReview(data.review);say('Review updated. Check the quantities, then add selected items.');};
    const showResults = result => {
      done=true;dirty=false;content.replaceChildren();
      const added=result.items.filter(r=>r.added>0).length,failed=result.items.length-added,uncertain=result.items.some(r=>r.status==='uncertain');
      content.append(el('h3',`${added} item${added===1?'':'s'} added to cart${failed?` · ${failed} not added`:''}`,'pdou-summary'));
      const list=el('div',undefined,'pdou-results');
      result.items.forEach(r=>{const card=el('div',undefined,`pdou-result ${r.added?'pdou-ready':'pdou-error'}`);card.append(el('strong',r.name||r.sku),el('small',r.sku,'pdou-muted'),el('p',r.added?`${r.added} added · ${r.price?.known?money(r.price.unit_ex_tax,result.currency)+' each ex GST':'See cart for price'}`:r.reason));if(r.price?.bulk_applied)card.append(el('strong','Bulk discount applied','pdou-discount'));list.append(card);});content.append(list);
      const bar=el('div',undefined,'pdou-actions'),cart=el('a','View cart','pdou-button');
      const url=new URL(result.cart_url,location.href);if(url.origin===location.origin)cart.href=url.href;
      bar.append(cart,button('Continue ordering','continue','pdou-secondary'),button('Download results report','report','pdou-text-button'),button('Upload another file','reset','pdou-text-button'));content.append(bar);
      say(uncertain?'Some additions could not be verified. Check the quantities in your cart before ordering again.':failed?'Some items were not added. Review the results below.':'Your selected items have been added to the cart.');
      document.dispatchEvent(new CustomEvent('pdou:complete',{detail:{items:result.items},bubbles:true}));
      if(window.jQuery)window.jQuery(document.body).trigger('wc_fragment_refresh');
      const store=window.wp?.data?.dispatch?.('wc/store/cart');if(store?.invalidateResolutionForStoreSelector)store.invalidateResolutionForStoreSelector('getCartData');
    };
    const showProgress = progress => {
      dirty=false;done=false;content.replaceChildren();
      content.append(el('h3',`Order progress: ${progress.completed} of ${progress.total} items checked`,'pdou-summary'));
      const bar=el('div',undefined,'pdou-actions');
      if(progress.needs_check){
        content.append(el('p','Check your cart before continuing. Some items from the interrupted group may already have been added.','pdou-cart-warning'));
        const cart=el('a','View cart','pdou-button');if(cartURL)cart.href=cartURL;cart.target='_blank';cart.rel='noopener';bar.append(cart,button('I’ve checked my cart — finish this review','recover'));
        say(progress.message||'Ordering was interrupted. Check your cart before trying again.',true);
      }else{bar.append(button('Continue adding remaining items','resume'));say(`Adding your order… ${progress.completed} of ${progress.total} items checked.`);}
      content.append(bar);
    };
    const runConfirmation = async first => {
      let result=first;
      while(result.progress){
        showProgress(result.progress);
        if(result.progress.needs_check)return;
        result=(await request('advance',{token:review.token,version:String(review.version)})).results;
      }
      showResults(result);
    };
    content.addEventListener('input',e=>{if(e.target.matches('[data-field]')){dirty=true;updateButtons();}});
    content.addEventListener('change',e=>{if(e.target.matches('[data-field=selected]')){dirty=true;updateButtons();}});
    content.addEventListener('click',e=>{
      const b=e.target.closest('[data-action]');if(!b||busy)return;
      const action=b.dataset.action;
      if(action==='upload'){
        const file=content.querySelector('input[type=file]').files[0];if(!file){say('Choose a CSV or Excel file first.',true);return;}
        if(!/\.(csv|xlsx)$/i.test(file.name)||file.size>256000){say('Choose a CSV or Excel .xlsx file no larger than 250 KB.',true);return;}
        let token = '';
        if (captchaConfig.enabled) {
          try { token = captchaId !== null ? window.grecaptcha.getResponse(captchaId) : ''; } catch (_) {}
          if (!captchaSolved || !token) { say('Complete the “I’m not a robot” check before uploading.',true); return; }
        }
        perform('Checking products and stock…',async()=>{try {const data=await request('upload',{order_file:file,captcha_token:token});showReview(data.review);say('Upload reviewed. Resolve any issues before adding selected items.');} finally {resetCaptcha();}});
      }else if(action==='revise')perform('Updating your review…',revise);
      else if(action==='available'){
        const tr=b.closest('.pdou-row'),row=review.rows.find(r=>r.id===tr.dataset.row);tr.querySelector('[data-field=quantity]').value=String(row.available);tr.querySelector('[data-field=selected]').checked=true;dirty=true;
        perform('Checking the accepted quantity…',revise);
      }else if(action==='remove'){
        const tr=b.closest('.pdou-row');tr.querySelector('[data-field=selected]').checked=false;
        // Keep issue rows visible for reporting, but mark the customer's intent.
        b.textContent='Excluded';b.dataset.unavailable='1';b.disabled=true;say('This item is excluded. You can continue with ready items.');
      }else if(action==='confirm'){
        if(dirty||done)return;
        const selected=Array.from(content.querySelectorAll('[data-field=selected]:checked')).map(n=>n.closest('.pdou-row').dataset.row);if(!selected.length)return;
        perform('Rechecking stock and adding items…',async()=>{const data=await request('confirm',{token:review.token,version:String(review.version),data:JSON.stringify(selected)});await runConfirmation(data.results);});
      }else if(action==='resume')perform('Continuing your saved order…',async()=>{await runConfirmation((await request('advance',{token:review.token,version:String(review.version)})).results);});
      else if(action==='recover')perform('Recording the interrupted review…',async()=>{showResults((await request('recover',{token:review.token,acknowledged:'checked'})).results);});
      else if(action==='report')perform('Preparing your report…',async()=>{
        const data=await request('report',{token:review.token});const url=URL.createObjectURL(new Blob(['\ufeff',data.report],{type:'text/csv;charset=utf-8'}));const a=el('a');a.href=url;a.download=done?'PD-upload-results.csv':'PD-upload-issues.csv';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);say('Report downloaded.');
      });
      else if(action==='reset'){start();say('Choose another file to start a new review.');}
      else if(action==='continue'){if(dialog?.open)dialog.close();const form=document.querySelector('[data-wwof-form]');if(form)form.scrollIntoView({behavior:'smooth',block:'start'});else say('Continue using the order form below.');}
    });
    const bootstrap = () => perform('Checking your wholesale account…',async()=>{const config=await request('bootstrap');nonce=config.nonce;try{const u=new URL(config.cart_url,location.href);if(u.origin===location.origin)cartURL=u.href;}catch(_){}captchaConfig=config.captcha || {enabled:false};if(config.resume){review={token:config.resume.token,version:config.resume.version};showProgress(config.resume.progress);return;}say('Upload your order to check products and available stock.');await mountCaptcha();});
    start();
    if (dialog && launch) {
      // The browser's top layer avoids Elementor clipping/z-index conflicts.
      // Moving the dialog also keeps transformed editor containers out of its ancestry.
      document.body.append(dialog);
      dialog.id = 'pdou-dialog-' + (++dialogSequence);
      launch.setAttribute('aria-controls', dialog.id);
      launch.setAttribute('aria-expanded', 'false');
      launch.addEventListener('click', () => {
        if (!dialog.open) dialog.showModal();
        launch.setAttribute('aria-expanded', 'true');
        if (!nonce) bootstrap(); else if (captchaConfig.enabled) { watchChallenge(); if (captchaLayer?.showPopover && !captchaLayer.matches(':popover-open')) captchaLayer.showPopover(); }
      });
      dialog.querySelector('.pdou-close').addEventListener('click', () => dialog.close());
      dialog.addEventListener('close', () => {
        launch.setAttribute('aria-expanded', 'false');
        if (challengeObserver) { challengeObserver.disconnect(); challengeObserver = null; }
        if (captchaLayer?.hidePopover && captchaLayer.matches(':popover-open')) captchaLayer.hidePopover();
        if (captchaConfig.enabled) resetCaptcha();
        if (launch.isConnected) launch.focus();
      });
      dialog.addEventListener('click', event => {
        const rect = dialog.getBoundingClientRect();
        if (event.target === dialog && (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom)) dialog.close();
      });
    } else bootstrap();
  });
})();
